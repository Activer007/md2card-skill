# Local quality gate: PASS

Mode: **release**. Commit: `fd625dd3d997026026929c826e631b66b395a053`.
Started: 2026-10-26T09:42:40.353Z. Finished: 2026-10-26T09:58:31.752Z.

Human visual acceptance: **not-performed**. PASS applies only to the selected scope.

| Check | Status | Seconds | Reason / logs |
| --- | --- | ---: | --- |
| static | PASS | 0.1 | Exit 0 [stdout](logs/004-static.stdout.log) · [stderr](logs/004-static.stderr.log) |
| unit | NOT-RUN | 0.0 | Outside selected mode/target  |
| doctor | PASS | 1.0 | Exit 0 [stdout](logs/005-doctor.stdout.log) · [stderr](logs/005-doctor.stderr.log) |
| browser | PASS | 1.6 | Exit 0 [stdout](logs/006-browser.stdout.log) · [stderr](logs/006-browser.stderr.log) |
| pdf-rasterizer | PASS | 0.1 | Exit 0 [stdout](logs/007-pdf-rasterizer.stdout.log) · [stderr](logs/007-pdf-rasterizer.stderr.log) |
| test | PASS | 504.4 | Exit 0 [stdout](logs/008-test.stdout.log) · [stderr](logs/008-test.stderr.log) |
| integration | PASS | 98.3 | Exit 0 [stdout](logs/009-integration.stdout.log) · [stderr](logs/009-integration.stderr.log) |
| gallery-check | PASS | 2.8 | Exit 0 [stdout](logs/010-gallery-check.stdout.log) · [stderr](logs/010-gallery-check.stderr.log) |
| evidence | PASS | 0.3 |   |
| baseline-screenshot-stage | PASS | 0.5 |   |
| screenshot-stage | PASS | 77.4 | Exit 0 [stdout](logs/014-screenshot-stage.stdout.log) · [stderr](logs/014-screenshot-stage.stderr.log) |
| baseline-photo-cover | PASS | 0.4 |   |
| photo-cover | PASS | 84.7 | Exit 0 [stdout](logs/018-photo-cover.stdout.log) · [stderr](logs/018-photo-cover.stderr.log) |
| baseline-visual-audit | PASS | 0.4 |   |
| visual-audit | PASS | 107.6 | Exit 0 [stdout](logs/022-visual-audit.stdout.log) · [stderr](logs/022-visual-audit.stderr.log) |
| baseline-wechat-covers | PASS | 0.4 |   |
| wechat-covers | PASS | 49.8 | Exit 0 [stdout](logs/026-wechat-covers.stdout.log) · [stderr](logs/026-wechat-covers.stderr.log) |
| gallery | PASS | 16.8 | Exit 0 [stdout](logs/027-gallery.stdout.log) · [stderr](logs/027-gallery.stderr.log) |
| source-unchanged | PASS | 2.7 |   |

Full commands, exit codes, environment, test counts, baseline identities and hashes: [report.json](report.json).

Artifact inventory: [artifacts.json](artifacts.json). Reports are authenticated by [receipt.json](receipt.json); the receipt is not a signature.
