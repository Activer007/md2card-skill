# Local quality gate: PASS

Mode: **fast**. Commit: `fd625dd3d997026026929c826e631b66b395a053`.
Started: 2026-10-26T09:43:29.107Z. Finished: 2026-10-26T09:43:41.402Z.

Human visual acceptance: **not-performed**. PASS applies only to the selected scope.

| Check | Status | Seconds | Reason / logs |
| --- | --- | ---: | --- |
| static | PASS | 0.1 | Exit 0 [stdout](logs/004-static.stdout.log) · [stderr](logs/004-static.stderr.log) |
| unit | PASS | 4.9 | Exit 0 [stdout](logs/008-unit.stdout.log) · [stderr](logs/008-unit.stderr.log) |
| doctor | NOT-RUN | 0.0 | Outside selected mode/target  |
| browser | NOT-RUN | 0.0 | Outside selected mode/target  |
| pdf-rasterizer | NOT-RUN | 0.0 | Outside selected mode/target  |
| test | NOT-RUN | 0.0 | Outside selected mode/target  |
| integration | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery-check | NOT-RUN | 0.0 | Outside selected mode/target  |
| evidence | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery | NOT-RUN | 0.0 | Outside selected mode/target  |
| source-unchanged | PASS | 3.1 |   |

Full commands, exit codes, environment, test counts, baseline identities and hashes: [report.json](report.json).

Artifact inventory: [artifacts.json](artifacts.json). Reports are authenticated by [receipt.json](receipt.json); the receipt is not a signature.
