# Local quality gate: PASS

Mode: **targeted**. Commit: `fd625dd3d997026026929c826e631b66b395a053`.
Started: 2026-10-26T09:58:42.396Z. Finished: 2026-10-26T09:59:07.954Z.

Human visual acceptance: **not-performed**. PASS applies only to the selected scope.

| Check | Status | Seconds | Reason / logs |
| --- | --- | ---: | --- |
| static | PASS | 0.1 | Exit 0 [stdout](logs/004-static.stdout.log) · [stderr](logs/004-static.stderr.log) |
| unit | NOT-RUN | 0.0 | Outside selected mode/target  |
| doctor | PASS | 0.9 | Exit 0 [stdout](logs/005-doctor.stdout.log) · [stderr](logs/005-doctor.stderr.log) |
| browser | PASS | 1.6 | Exit 0 [stdout](logs/006-browser.stdout.log) · [stderr](logs/006-browser.stderr.log) |
| pdf-rasterizer | PASS | 0.1 | Exit 0 [stdout](logs/007-pdf-rasterizer.stdout.log) · [stderr](logs/007-pdf-rasterizer.stderr.log) |
| test | NOT-RUN | 0.0 | Outside selected mode/target  |
| integration | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery-check | PASS | 1.5 | Exit 0 [stdout](logs/008-gallery-check.stdout.log) · [stderr](logs/008-gallery-check.stderr.log) |
| evidence | PASS | 0.2 |   |
| baseline-screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery | PASS | 15.9 | Exit 0 [stdout](logs/009-gallery.stdout.log) · [stderr](logs/009-gallery.stderr.log) |
| source-unchanged | PASS | 2.9 |   |

Full commands, exit codes, environment, test counts, baseline identities and hashes: [report.json](report.json).

Artifact inventory: [artifacts.json](artifacts.json). Reports are authenticated by [receipt.json](receipt.json); the receipt is not a signature.
