import test from 'node:test';import assert from 'node:assert/strict';test('intentional gate failure',()=>assert.fail('injected unit failure'));
