# Local quality gate: FAIL

Mode: **fast**. Commit: `43ed35ec6b8e2460e3edfa3eea6bbff6cb6460a6`.
Started: 2026-10-26T09:59:08.500Z. Finished: 2026-10-26T09:59:09.524Z.

Human visual acceptance: **not-performed**. PASS applies only to the selected scope.

| Check | Status | Seconds | Reason / logs |
| --- | --- | ---: | --- |
| static | PASS | 0.1 | Exit 0 [stdout](logs/004-static.stdout.log) · [stderr](logs/004-static.stderr.log) |
| unit | FAIL | 0.2 | Exit 1 [stdout](logs/008-unit.stdout.log) · [stderr](logs/008-unit.stderr.log) |
| doctor | NOT-RUN | 0.0 | Outside selected mode/target  |
| browser | NOT-RUN | 0.0 | Outside selected mode/target  |
| pdf-rasterizer | NOT-RUN | 0.0 | Outside selected mode/target  |
| test | NOT-RUN | 0.0 | Outside selected mode/target  |
| integration | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery-check | NOT-RUN | 0.0 | Outside selected mode/target  |
| evidence | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery | NOT-RUN | 0.0 | Outside selected mode/target  |
| source-unchanged | PASS | 0.3 |   |

Full commands, exit codes, environment, test counts, baseline identities and hashes: [report.json](report.json).

Artifact inventory: [artifacts.json](artifacts.json). Reports are authenticated by [receipt.json](receipt.json); the receipt is not a signature.
