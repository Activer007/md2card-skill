# Local quality gate: BLOCKED

Mode: **targeted**. Commit: `fd625dd3d997026026929c826e631b66b395a053`.
Started: 2026-10-26T09:59:17.806Z. Finished: 2026-10-26T09:59:24.745Z.

Human visual acceptance: **not-performed**. PASS applies only to the selected scope.

| Check | Status | Seconds | Reason / logs |
| --- | --- | ---: | --- |
| static | PASS | 0.1 | Exit 0 [stdout](logs/004-static.stdout.log) · [stderr](logs/004-static.stderr.log) |
| unit | NOT-RUN | 0.0 | Outside selected mode/target  |
| doctor | BLOCKED | 0.8 | Strict environment preflight did not pass; see doctor checks and logs [stdout](logs/005-doctor.stdout.log) · [stderr](logs/005-doctor.stderr.log) |
| browser | NOT-RUN | 0.0 | Prerequisite did not pass: doctor  |
| pdf-rasterizer | NOT-RUN | 0.0 | Prerequisite did not pass: doctor  |
| test | NOT-RUN | 0.0 | Outside selected mode/target  |
| integration | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery-check | PASS | 1.6 | Exit 0 [stdout](logs/006-gallery-check.stdout.log) · [stderr](logs/006-gallery-check.stderr.log) |
| evidence | PASS | 0.2 |   |
| baseline-screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| screenshot-stage | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| photo-cover | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| visual-audit | NOT-RUN | 0.0 | Outside selected mode/target  |
| baseline-wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| wechat-covers | NOT-RUN | 0.0 | Outside selected mode/target  |
| gallery | NOT-RUN | 0.0 | Prerequisite did not pass: doctor, browser, pdf-rasterizer  |
| source-unchanged | PASS | 2.0 |   |

Full commands, exit codes, environment, test counts, baseline identities and hashes: [report.json](report.json).

Artifact inventory: [artifacts.json](artifacts.json). Reports are authenticated by [receipt.json](receipt.json); the receipt is not a signature.
