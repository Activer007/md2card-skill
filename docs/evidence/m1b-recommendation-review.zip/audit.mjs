import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { parseRecommendationOptions, createRecommendationReport } from '../../scripts/recommend-templates.mjs';
import { TEMPLATES } from '../../scripts/templates.mjs';
import { buildGalleryModel } from '../../scripts/build-template-gallery.mjs';
const hash = value => createHash('sha256').update(value).digest('hex');
const model = await buildGalleryModel();
const cases = [];
for (const entry of model.aspectEvidence.entries) {
  const report = await createRecommendationReport(parseRecommendationOptions([entry.input, '--size', entry.aspect, '--asset-root', 'examples/templates']));
  const candidate = report.cards[0].candidates.find(c => c.templateId === entry.template);
  assert.ok(candidate, entry.id);
  assert.equal(candidate.acceptedExample.input, entry.input);
  assert.equal(candidate.acceptedExample.png.sha256, entry.views.fullPng.sha256);
  for (const candidate of report.cards.flatMap(c => c.candidates)) {
    assert.ok(TEMPLATES.find(t => t.id === candidate.templateId).aspects.includes(entry.aspect));
    if (candidate.acceptedExample) assert.equal(candidate.acceptedExample.aspect, entry.aspect);
    assert.equal(candidate.inputRenderability, 'not-verified');
  }
  cases.push({ id: entry.id, input: entry.input, aspect: entry.aspect, template: entry.template, png: candidate.acceptedExample.png, status: 'pass' });
}
const base = '013944d0edad904a194003491bf58ddd46e22c88';
const unchanged = ['scripts/render.mjs', 'scripts/markdown.mjs', 'scripts/assets.mjs', 'scripts/document.mjs', 'scripts/templates.mjs', 'docs/gallery/gallery.js', 'docs/gallery/gallery.css', 'docs/gallery-comparisons.json', 'docs/template-gallery-evidence.json', 'docs/aspect-gallery-evidence.json'];
for (const file of unchanged) assert.equal(hash(await readFile(file)), hash(execFileSync('git', ['show', `${base}:${file}`])), file);
const report = { base, status: 'pass', templateCount: model.items.length, portraitPreviews: model.accepted.length,
  comparisonPreviews: model.comparisons.flatMap(g => g.previews).length, independentAspectFixtures: cases, unchanged };
await writeFile('validation/m1b/completion-audit.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, templates: report.templateCount, portraitPreviews: report.portraitPreviews, comparisonPreviews: report.comparisonPreviews, independentAspectFixtures: cases.length, unchanged: unchanged.length }));
