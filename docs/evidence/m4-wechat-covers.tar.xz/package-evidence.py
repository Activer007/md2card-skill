from pathlib import Path
import hashlib, json, tarfile, shutil, re

root=Path(__file__).resolve().parents[2]
run=root/'validation/m4/final9'
report=json.loads((run/'report.json').read_text(encoding='utf-8'))
sha=lambda data:hashlib.sha256(data).hexdigest()
for item in report['source']:
    assert sha((root/item['file']).read_bytes())==item['sha256'],item['file']
assert (run/'default-compatibility.json').read_bytes()==(root/'docs/visual-upgrade/m4-default-compatibility.json').read_bytes()
logs=root/'validation/m4'
for filename in ['unit-full-final.txt','integration-final.txt']:
    text=(logs/filename).read_text(encoding='utf-8')
    assert re.search(r'(?:ℹ|#)\s*fail\s+0\b',text),filename
    assert re.search(r'(?:ℹ|#)\s*skipped\s+0\b',text),filename

images=root/'docs/images/m4-wechat-covers';images.mkdir(parents=True,exist_ok=True)
pdfs=root/'docs/evidence/m4-wechat-covers';pdfs.mkdir(parents=True,exist_ok=True)
views=[]
for template,side in [('T01','square'),('T01','wide'),('T21','wide')]:
    folder=run/f'{template}-pair'/side
    for source,suffix in [('card-001.png','native'),('preview-375.png','375'),('preview-390.png','390')] if side=='square' else [('card-001.png','native'),('preview-840.png','840'),('preview-1200.png','1200')]:
        target=images/f'{template}-{side}-{suffix}.png';shutil.copyfile(folder/source,target)
        views.append({'file':target.relative_to(root).as_posix(),'sha256':sha(target.read_bytes())})
    target=pdfs/f'{template}-{side}.pdf';shutil.copyfile(folder/'cards.pdf',target)
    views.append({'file':target.relative_to(root).as_posix(),'sha256':sha(target.read_bytes())})

snapshot=run/'source-snapshot';snapshot.mkdir(exist_ok=True)
extra=['scripts/default-body-compatibility.mjs','scripts/build-template-gallery.mjs','tests/wechat-covers.test.mjs','examples/wechat-covers/T01-square.md','examples/wechat-covers/T01-wide.md','examples/wechat-covers/T21-square.md','examples/wechat-covers/T21-wide.md']
for filename in dict.fromkeys([x['file'] for x in report['source']]+extra):
    target=snapshot/filename;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/filename,target)
for filename in ['unit-full-final.txt','integration-final.txt','proof-final.txt','validation-final9.log','validation-final8.log','validation-final6.log','refused-T04.stderr.json','refused-ratio.stderr.json']:
    target=run/'logs'/filename;target.parent.mkdir(exist_ok=True);shutil.copyfile(logs/filename,target)
anomaly=run/'anomalies';anomaly.mkdir(exist_ok=True)
for side in ['current','baseline']:
    shutil.copyfile(logs/f'final6/compat-T21-slide-{side}/card-001.png',anomaly/f'T21-slide-{side}.png')
shutil.copyfile(logs/'pixel-anomaly.json',anomaly/'pixel-anomaly.json')
shutil.copyfile(Path(__file__),run/'package-evidence.py')
records=[{'file':p.relative_to(run).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(run.rglob('*')) if p.is_file()]
archive=root/'docs/evidence/m4-wechat-covers.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for entry in records:
        info=tar.gettarinfo(str(run/entry['file']),arcname=entry['file']);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
        with (run/entry['file']).open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(archive,'r:xz') as tar:
    assert len(tar.getmembers())==len(records)
    for entry in records:assert sha(tar.extractfile(entry['file']).read())==entry['sha256']
proof={'schemaVersion':1,'baselineCommit':report['baselineCommit'],'scope':'T01 square, T01 wechat-wide, T21 wechat-wide only','humanVisualReview':'not-performed','semanticEquivalence':'not-verified','agentVisualInspection':'three native PDF page images and eight responsive previews inspected; no clipping or overlap seen in these exact fixtures','archive':archive.relative_to(root).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'fileCount':len(records),'tests':{},'views':views,'source':report['source'],'files':records}
for kind,filename in [('unit','unit-full-final.txt'),('integration','integration-final.txt'),('compatibilityProof','proof-final.txt')]:
    text=(logs/filename).read_text(encoding='utf-8');proof['tests'][kind]={key:int(re.search(r'(?:ℹ|#)\s*'+key+r'\s+(\d+)\b',text).group(1)) for key in ['tests','pass','fail','skipped']}
(root/'docs/visual-upgrade/m4-evidence.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({key:proof[key] for key in ['archive','sha256','bytes','fileCount','tests']},ensure_ascii=False))
