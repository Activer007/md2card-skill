from pathlib import Path
import json,hashlib,zipfile
root=Path('.');run=root/'validation/pr28-review/final';oldm=json.loads((root/'docs/visual-upgrade/m2a-evidence.json').read_text(encoding='utf8'));oldpath=root/oldm['archive']['file'];sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(oldpath.read_bytes())==oldm['archive']['sha256']
report=json.loads((run/'report.json').read_text(encoding='utf8'));assert len(report['records'])==28
comparisons=[];differences=[]
archive=root/'docs/evidence/t20-pr28-review.zip';added=[];reused=[]
with zipfile.ZipFile(oldpath) as old,zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as new:
 for r in report['records']:
  case=r['id']+'-'+r['mode'];folder=run/case
  if r['outcome']=='exported':
   source=(run/(case+'.md')).read_text(encoding='utf8');meta=json.loads(source.splitlines()[0][11:-4]);assert sha((root/meta['image']).read_bytes())==r['views']['screen']['imageSha256']
   for filename in ['card-001.png','screen.png','print.png','mobile-375.png','mobile-390.png','native-pdf.png','pdf-raw.txt']:
    name='run/'+case+'/'+filename;digest=sha((folder/filename).read_bytes());before=sha(old.read(name))
    if digest!=before:
     assert filename=='card-001.png' and case in ['desktop-16x9-default','long-body-default'],name
     from PIL import Image,ImageChops
     import io
     diff=ImageChops.difference(Image.open(io.BytesIO(old.read(name))).convert('RGB'),Image.open(folder/filename).convert('RGB'))
     count=sum(any(p) for p in diff.getdata());assert count==({'desktop-16x9-default':9,'long-body-default':109}[case]);assert max(v[1] for v in diff.getextrema())==1
     differences.append({'file':name,'oldSha256':before,'newSha256':digest,'changedPixels':count,'maxChannelDifference':1,'bbox':diff.getbbox(),'review':'Individually inspected; differences are inside embedded raster only; complete text/layout retained.'})
    else:comparisons.append({'file':name,'sha256':digest})
  else:
   files=sorted(p.name for p in folder.iterdir()) if folder.exists() else []
   assert files==(['overflow.json'] if r['code']=='CONTENT_OVERFLOW' else []),(case,files)
 for p in sorted(run.rglob('*')):
  if not p.is_file() or p.name=='progress.json':continue
  name='run/'+p.relative_to(run).as_posix();data=p.read_bytes();item={'file':name,'bytes':len(data),'sha256':sha(data)}
  if name in old.namelist() and sha(old.read(name))==item['sha256']:reused.append(item)
  else:new.writestr(name,data);added.append(item)
 for p in [root/'scripts/validate-screenshot-stage.mjs',root/'tests/screenshot-stage.test.mjs',*(root/'validation/pr28-review'/f for f in ['unit.log','targeted.log','render.log','final-render.log','pixel-differences.json','pixel-diff.py','package.py'])]:
  name='audit/'+p.name;data=p.read_bytes();new.writestr(name,data);added.append({'file':name,'bytes':len(data),'sha256':sha(data)})
manifest={'schemaVersion':1,'reviewedPrHead':'be753dd00771627a1d9e3d071e37afc39fcb2b4c','baseCommit':report['baseCommit'],'baselineIdentity':report['baselineIdentity'],'sourceHashes':report['sourceHashes'],'archive':{'file':archive.as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'reusedArchive':oldm['archive'],'addedFiles':added,'reusedFiles':reused,'visualAndTextEquivalence':comparisons,'reviewedPixelDifferences':differences,'checks':{'unit':{'passed':601,'skipped':3,'failed':0},'targeted':{'passed':14,'failed':0},'exported':sum(r['outcome']=='exported' for r in report['records']),'refused':sum(r['outcome']=='refused' for r in report['records']),'githubActions':'disabled; no remote checks','firstBrowserRun':'failed BROWSER_CLEANUP_TIMEOUT; retained in audit/render.log','finalBrowserRun':'passed with original cleanup limit'},'reviewScope':'110 exact image/text files and two individually reviewed raster differences; not a maintainer visual approval.'}
(root/'docs/visual-upgrade/pr28-review-evidence.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
with zipfile.ZipFile(archive) as z,zipfile.ZipFile(oldpath) as old:
 for f in added:assert sha(z.read(f['file']))==f['sha256']
 for f in reused:assert sha(old.read(f['file']))==f['sha256']
print('Verified:',len(comparisons),'identical views/text files;',len(added),'new files;',len(reused),'reused files; ZIP',archive.stat().st_size,'bytes')
