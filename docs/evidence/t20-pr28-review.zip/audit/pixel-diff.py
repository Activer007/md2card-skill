from pathlib import Path
from PIL import Image,ImageChops
import zipfile,json,io
r=Path('validation/pr28-review/final');m=json.loads((r/'report.json').read_text(encoding='utf8'))
with zipfile.ZipFile('docs/evidence/t20-screenshot-stage-m2a.zip') as z:
 for item in m['records']:
  if item['outcome']!='exported':continue
  case=item['id']+'-'+item['mode']
  for name in ['card-001.png','screen.png','print.png','mobile-375.png','mobile-390.png','native-pdf.png']:
   a=Image.open(io.BytesIO(z.read('run/'+case+'/'+name))).convert('RGB');b=Image.open(r/case/name).convert('RGB');diff=ImageChops.difference(a,b);box=diff.getbbox()
   if box:print(case,name,box,'changed pixels',sum(any(p) for p in diff.getdata()))
