from PIL import Image,ImageDraw
from pathlib import Path
root=Path('validation/m2a/final-complete');out=Path('validation/m2a/review');out.mkdir(exist_ok=True)
for stage in root.glob('*-stage'):
 if not (stage/'native-pdf.png').exists():continue
 key=stage.name[:-6];sheet=Image.new('RGB',(1500,1100),'white');draw=ImageDraw.Draw(sheet)
 for row,mode in enumerate(['default','stage']):
  folder=root/(key+'-'+mode)
  for col,name in enumerate(['card-001.png','mobile-375.png','mobile-390.png','native-pdf.png']):
   im=Image.open(folder/name).convert('RGB')
   if name.startswith('mobile'):im=im.crop((0,0,im.width,540))
   im.thumbnail((375,520));sheet.paste(im,(col*375,row*550+26));draw.text((col*375+5,row*550+5),f'{key} {mode} {name}',fill='black')
 sheet.save(out/(key+'.png'))

