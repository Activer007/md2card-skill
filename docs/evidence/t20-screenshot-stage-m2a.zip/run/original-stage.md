<!-- card: {"template":"T20","eyebrow":"PRODUCT CONCEPT / 研究工作台","image":"examples/templates/assets/original-research-interface.png","alt":"原创虚构研究工作台界面插画，含导航、内容卡片与资料区域；不是现有产品截图","caption":"原创界面插画 · 非真实产品截图","source":"原创概念演示 · 不代表已上线功能","visualVariant":"screenshot-stage"} -->
# 把资料放回问题里

一个虚构研究工作台的功能设想。

## 整理材料

按主题收集片段，保留原始出处。

## 回到问题

并排查看笔记，记录待验证项。
