import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {renderCards} from '../scripts/markdown.mjs';
import {createAssetResolver} from '../scripts/assets.mjs';
import {visibleSegments,assertPdfSegments} from '../scripts/validate-series.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const dest='docs/evidence/t37-default-contrast';await fs.mkdir(dest,{recursive:true});
const read=async f=>JSON.parse(await fs.readFile(f));
const first=await read('validation/t37-contrast/run1/report.json'),last=await read('validation/t37-contrast/run3/report.json');
assert.equal(first.status,'fail');assert.equal(last.status,'pass');
const records=first.records.filter(r=>r.pixels&&Object.keys(r.pixels).length===5).map(r=>({...r,run:'run1'}));
assert.equal(records.length,10);records.push({...last.records[0],run:'run3'});
assert.equal(new Set(records.map(r=>r.id)).size,11);
const resolveImage=(await createAssetResolver(process.cwd())).resolveImage;
for(const run of [first,last])for(const p of run.sourceHashes.filter(p=>p.file!=='scripts/validate-t37-contrast.mjs'))assert.equal(hash(await fs.readFile(p.file)),p.sha256,p.file);
for(const r of records){
 const source=await fs.readFile(`validation/t37-contrast/${r.run}/${r.id}.md`,'utf8');assert.equal(hash(source),r.inputSha256);
 const expected=[...renderCards(source,{resolveImage}).flatMap(visibleSegments),'PHOTO STUDY · 合成示例','版式练习 · 不构成事实记录'];
 for(const version of ['before','after']){
  const dir=`validation/t37-contrast/${r.run}/${r.id}-${version}`;
  assert.equal(hash(await fs.readFile(`${dir}/cards.html`)),r.versions[version].htmlSha256);
  assertPdfSegments(await fs.readFile(`${dir}/pdf-raw.txt`,'utf8'),expected,r.id);
  r.versions[version].sourceCoverage={extractor:'Poppler -raw',normalization:'NFC and whitespace only',expected,missing:[]};
 }
 for(const [media,difference] of Object.entries(r.pixels))assert.equal(difference.changedPixels>0,r.expectedChange,`${r.id}/${media}`);
 for(const media of ['screen','print','mobile375','mobile390']){
  const a=r.versions.before.views[media],b=r.versions.after.views[media];assert.equal(a.bodyText,b.bodyText);assert.deepEqual(a.images,b.images);assert.deepEqual(a.texts.map(t=>t.box),b.texts.map(t=>t.box));
  if(!r.id.endsWith('control'))for(const t of b.texts)if(t.ratio!==null)assert.ok(t.ratio>=4.5);
 }
}
const files=[];
async function inventory(dir,rel){for(const e of await fs.readdir(dir,{withFileTypes:true})){const f=`${dir}/${e.name}`,p=`${rel}/${e.name}`;if(e.isDirectory())await inventory(f,p);else {const b=await fs.readFile(f);files.push({file:p,bytes:b.length,sha256:hash(b)});}}}
for(const name of ['run1','run2','run3']){
 await inventory(`validation/t37-contrast/${name}`,name);
 await fs.copyFile(`validation/t37-contrast/${name}/report.json`,`${dest}/${name}-report.json`);
 await fs.copyFile(`validation/t37-contrast/${name}.log`,`${dest}/${name}.log`);
}
await fs.copyFile('validation/t37-contrast/probe-report.json',`${dest}/probe-report.json`);
await fs.copyFile('validation/t37-contrast/probe.mjs',`${dest}/probe-source.mjs`);
const probe=await read(`${dest}/probe-report.json`);assert.equal(probe.status,'pass');
const report={schemaVersion:1,status:'pass',scope:'11 explicit before/after cases; completed run1 rows plus targeted run3; not a whole-run1 pass',baselineCommit:first.baselineCommit,browser:first.browser,sourceHashes:first.sourceHashes.filter(p=>p.file!=='scripts/validate-t37-contrast.mjs'),currentValidatorSha256:hash(await fs.readFile('scripts/validate-t37-contrast.mjs')),runs:[{file:'run1-report.json',status:'fail',reason:'T20 layout-order text extractor interleaved columns; ten preceding complete cases retained'},{file:'run2-report.json',status:'fail',reason:'T20 passed; targeted run omitted black.md for production export'},{file:'run3-report.json',status:'pass',reason:'T20 raw source coverage, production export and CONTENT_OVERFLOW refusal passed'}],compatibility:first.compatibility,records,production:last.production,overflow:last.overflow,probe:{file:'probe-report.json',sha256:hash(await fs.readFile(`${dest}/probe-report.json`))},archiveFiles:files,humanVisualReview:'pending',limitations:first.limitations};
await fs.writeFile(`${dest}/report.json`,JSON.stringify(report,null,2)+'\n');
for(const [id,version,file] of [['black','before','screen.png'],['black','after','screen.png'],['light-white','before','screen.png'],['light-white','after','screen.png'],['black','after','mobile-375.png'],['light-white','after','mobile-390.png']])await fs.copyFile(`validation/t37-contrast/run1/${id}-${version}/${file}`,`${dest}/${id}-${version}-${file}`);
const html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>T37 新旧实测对照</title><style>body{font:16px system-ui;margin:24px;background:#eee;color:#222}section{margin:32px 0}.pair{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}img{max-width:100%}@media(max-width:600px){.pair{grid-template-columns:1fr}}</style><h1>T37 新旧实测对照</h1><p>真实 Chromium 输出。before 为 0ce7e16；after 为本次修复。原始输入、HTML、PNG、375/390、PDF 和失败记录均保留。维护者视觉签收 pending。</p>${records.map(r=>`<section><h2>${r.id} · ${r.expectedChange?'受控文字颜色修复':'像素一致'}</h2>${['screen','print','mobile-375','mobile-390','native-pdf'].map(n=>`<h3>${n}</h3><div class="pair">${['before','after'].map(v=>`<div><p>${v} · <a href="${r.run}/${r.id}-${v}/cards.pdf">原生 PDF</a> · <a href="${r.run}/${r.id}-${v}/preview.html">HTML</a></p><img loading="lazy" alt="${r.id} ${v} ${n}" src="${r.run}/${r.id}-${v}/${n}.png"></div>`).join('')}</div>`).join('')}</section>`).join('')}</html>`;
await fs.writeFile('validation/t37-contrast/index.html',html);
console.log(JSON.stringify({cases:records.length,files:files.length,pixels:records.map(r=>[r.id,r.pixels.screen.changedPixels])}));
