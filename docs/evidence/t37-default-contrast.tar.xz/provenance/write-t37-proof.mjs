import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {buildDocument} from '../scripts/document.mjs';
import {renderCards} from '../scripts/markdown.mjs';
import {createAssetResolver} from '../scripts/assets.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
const previous=JSON.parse(await fs.readFile('docs/visual-upgrade/m4-default-compatibility.json'));
const report=JSON.parse(await fs.readFile('docs/evidence/t37-default-contrast/report.json'));
assert.equal(report.status,'pass');
const baseline=await import('./t37-contrast/baseline/scripts/document.mjs');
const styles=await Promise.all(['themes','layouts','templates'].map(n=>fs.readFile(`assets/${n}.css`,'utf8')));
const photo=JSON.parse(await fs.readFile('docs/visual-upgrade/m2b-default-compatibility.json'));
const resolver=await createAssetResolver(process.cwd());
const extra=[];
for(const f of [...photo.stageRecords.map(r=>({input:r.input,options:r.options})),...['bright','dark','portrait','three-line'].map(id=>({input:`examples/visual-upgrade/t37/${id}.md`,options:{width:1080,height:1440}}))]){
 const input=await fs.readFile(f.input,'utf8'),cards=renderCards(input,{resolveImage:resolver.resolveImage});
 for(const accent of [undefined,'#000000','#e4c37d']){
  const options={...f.options,...(accent?{brand:{accent}}:{})};
  const before=baseline.buildDocument(cards,options,...styles),after=buildDocument(cards,options,...styles);
  assert.equal(after,before,f.input);
  extra.push({id:f.input,accent:accent??null,inputSha256:sha(input),htmlSha256:sha(after)});
 }
}
const proof={schemaVersion:1,scope:'unchanged-gallery-fixtures-only;unsafe-T37-default-brands-excluded',baselineCommit:'0ce7e161b20d2bad1dd789150dd16acd98b00c2f',files:{},htmlRecords:[...report.compatibility,...extra],controlledChanges:report.records.filter(r=>r.expectedChange).map(r=>({id:r.id,inputSha256:r.inputSha256,policy:r.policy,pixels:r.pixels})),browserReport:{file:'docs/evidence/t37-default-contrast/report.json',sha256:sha(await fs.readFile('docs/evidence/t37-default-contrast/report.json'))},humanVisualReview:'pending'};
for(const file of Object.keys(previous.files)){
 const old=sha(await fs.readFile('validation/t37-contrast/baseline/'+file));
 assert.equal(old,previous.files[file].currentSha256,file);
 proof.files[file]={baselineSha256:old,currentSha256:sha(await fs.readFile(file))};
}
const text=JSON.stringify(proof,null,2)+'\n';await fs.writeFile('docs/visual-upgrade/t37-contrast-compatibility.json',text);console.log(sha(text),proof.htmlRecords.length);
