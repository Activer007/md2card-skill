<!-- card: {"template":"T37","eyebrow":"","image":"examples/visual-upgrade/t37/assets/synthetic-bright-shore.png","alt":"AI 合成的海岸与小船，非真实地点或摄影记录","caption":"AI 合成图像，非实拍。","source":"原创合成练习 · 无第三方摄影"} -->
# 在沿岸慢行时留下一段值得**再次观察**的光影

保留来源。
