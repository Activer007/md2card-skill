<!-- card: {"template":"T37","image":"examples/visual-upgrade/t37/assets/synthetic-dark-vase.png","alt":"AI 合成的暗墙、花枝与陶瓶","caption":"AI 合成图像，非实拍。","source":"原创合成练习 · 无第三方摄影","eyebrow":"LIGHT / 01"} -->
# 暗处 **有光**

让花枝与陶瓶留在画面右侧，左侧文字记录一次光影练习。
