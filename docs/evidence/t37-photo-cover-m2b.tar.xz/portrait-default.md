<!-- card: {"template":"T37","image":"examples/visual-upgrade/t37/assets/synthetic-quiet-portrait.png","alt":"AI 合成的虚构成年女性，人物位于右侧","caption":"虚构人物，AI 合成，非真实肖像。","source":"原创合成练习 · 无第三方摄影","eyebrow":"PORTRAIT / 03"} -->
# [片刻](https://example.com) 安静

这是虚构成年人物的合成练习，不是采访、人物报道或身份记录。
