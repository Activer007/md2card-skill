from pathlib import Path
from PIL import Image,ImageChops
import json,hashlib,html
root=Path('validation/m2b/run1')
report=json.loads((root/'report.json').read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
notes={
 'bright-photo':'右上亮底黑字；小船完整，标题不覆盖船或岸线。',
 'dark-photo':'左下深底白字；花枝与陶瓶完整，标题与主体分开。',
 'portrait-photo':'左上白字；虚构人物面部和头部未被文字覆盖，原始照片的肩部边界仍是画面边界。',
 'three-line-photo':'三行原文完整；局部底板仍在左下安全区，未覆盖花枝/陶瓶。',
 'blocked-portrait-default':'竖图完整 contain，头部、手与器物全部保留；适合回退。',
 'no-safe-zone-default':'静物全幅保留，标题置于图外，无图文遮挡。',
 'no-crop-permission-default':'未授权裁切时全幅保留；标题、来源、页脚完整。',
 'three-line-default':'原文保持一行标题；完整图像，正文与来源完整。',
 'bright-default':'完整图像、标题和正文保留；纯黑品牌色使眉题对比不足，是 main 已有表现。',
 'dark-default':'完整图像保留；纯黑品牌色使眉题和加粗标题片段对比不足，是 main 已有表现。',
 'portrait-default':'完整图像保留；纯黑品牌色使眉题和标题链接对比不足，是 main 已有表现。',
 'original-default':'HTML/PNG/PDF 页图与 main 完全相同；纯黑品牌色导致眉题对比不足，不能标为新视觉通过。'
}
records=[]
for row in report['records']:
 if row['outcome']!='exported':continue
 key=f"{row['id']}-{row['mode']}";folder=root/key
 views=[{'file':f'{key}/{n}','sha256':digest(folder/n),'inspection':'individually visually inspected by Codex'}for n in ['card-001.png','mobile-375.png','mobile-390.png','native-pdf.png']]
 comparisons=[]
 for name in ['screen.png','print.png']:
  a=Image.open(folder/'card-001.png').convert('RGB');b=Image.open(folder/name).convert('RGB');diff=ImageChops.difference(a,b);bbox=diff.getbbox()
  comparisons.append({'file':name,'equalPixels':bbox is None,'changedBounds':bbox,'changedPixels':sum(1 for p in diff.getdata() if p!=(0,0,0)) if bbox else 0,'maxChannelDelta':max(c[1] for c in diff.getextrema()),'inspection':'Two nonidentical blocked-portrait views individually inspected; differences confined to embedded image.' if bbox else 'Exact pixel match to inspected full PNG.'})
 records.append({'id':key,'verdict':'photo composition accepted for this exact fixture' if row['mode']=='photo' else 'default compatibility only; existing contrast caveat' if key in ['bright-default','dark-default','portrait-default','original-default'] else 'complete-image fallback inspected','notes':notes[key],'views':views,'screenPrintComparison':comparisons})
def lum(x):
 x=x/255
 return x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4
contrast={'method':'Conservative sRGB worst-case backing compositing; actual foreground/backing also captured from computed styles. Does not assess subject semantics.', 'darkWhiteOnWhitestBackground':1.05/(lum(255*(1-.76))+.05),'lightBlackOnBlackestBackground':(lum(255*.84)+.05)/(lum(17)+.05)}
review={'schemaVersion':1,'date':'2026-10-26','automatedReportSha256':digest(root/'report.json'),'scope':'48 individually inspected full PNG/mobile/native-PDF page views; 12 native PDFs separately source-text checked by Poppler. Screen/print duplicates compared pixel-by-pixel.','records':records,'contrast':contrast,'limits':['Only these exact synthetic fixtures and installed fonts are accepted.','Safety declarations are author judgments, not automatic face detection.','Intentional black-brand stress exposes existing default accent contrast problems; unchanged defaults are not newly visually approved.']}
(root/'visual-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sections=[]
for id in dict.fromkeys(r['id'] for r in report['records']):
 rows=[r for r in report['records']if r['id']==id]
 cells=[]
 for r in rows:
  key=f"{r['id']}-{r['mode']}"
  if r['outcome']=='refused':cells.append(f'<article><h3>{html.escape(key)}</h3><p>明确拒绝：{r["code"]}</p><pre>{html.escape(r["message"])}</pre><a href="{key}.md">原始输入</a></article>');continue
  cells.append(f'<article><h3>{key}</h3><p>{notes[key]}</p><a href="{key}/card-001.png"><img src="{key}/card-001.png" alt="{key}完整卡片"></a><p><a href="{key}/mobile-375.png">375 预览</a> · <a href="{key}/mobile-390.png">390 预览</a> · <a href="{key}/cards.pdf">原生 PDF</a> · <a href="{key}/native-pdf.png">PDF 页图</a> · <a href="{key}/pdf-raw.txt">提取文字</a> · <a href="{key}.md">输入</a></p></article>')
 sections.append(f'<section><h2>{id}</h2><div class="pair">'+''.join(cells)+'</div></section>')
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>T37 照片封面对照</title><style>body{font:16px/1.6 system-ui;background:#f5f3ee;color:#17211d;margin:32px auto;max-width:1200px;padding:0 20px}h1{font-size:32px}.pair{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:28px}article{background:white;padding:20px}img{width:100%;height:auto}pre{white-space:pre-wrap;overflow-wrap:anywhere}section{margin:40px 0}a{color:#17534a}@media(max-width:650px){.pair{grid-template-columns:1fr}}</style><h1>T37：完整图像与可选照片封面</h1><p>本组全部为 AI 合成图。只有作者明确授权裁切并确认安全区后，才能启用 photo-cover。这里没有自动人脸识别或主体避让。</p><p>为验证前景色不受品牌色覆盖，本轮故意使用纯黑强调色。旧默认的眉题/强调文字因此有既存对比问题；默认未更改，不能将相同字节误称为视觉通过。新封面直接指定图片上的文字颜色。</p><p><a href="visual-review.json">逐图视觉结论与哈希</a> · <a href="report.json">自动验证原始报告</a> · <a href="originals/">完整原图</a></p>'''+''.join(sections)+'</html>'
(root/'index.html').write_text(page,encoding='utf-8')
print(json.dumps({'reviewed':len(records)*4,'contrast':contrast,'nonidenticalScreenPrint':[(r['id'],c)for r in records for c in r['screenPrintComparison']if not c['equalPixels']]},ensure_ascii=False))
