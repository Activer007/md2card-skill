import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const dir='examples/visual-upgrade/t37';
const common={template:'T37',visualVariant:'photo-cover',imageRole:'photo',mediaFit:'cover',focalX:100,focalY:50,textZone:'bottom-left',mediaTone:'dark',subjectSafety:'clear',image:`${dir}/assets/synthetic-dark-vase.png`,alt:'AI 合成的暗墙、花枝与陶瓶',caption:'AI 合成图像，非实拍。',source:'原创合成练习 · 无第三方摄影',eyebrow:'LIGHT / 01'};
const cases={
 'dark':{title:'暗处\u0020**有光**',body:'让花枝与陶瓶留在画面右侧，左侧文字记录一次光影练习。'},
 'bright':{meta:{image:`${dir}/assets/synthetic-bright-shore.png`,focalX:0,textZone:'top-right',mediaTone:'light',alt:'AI 合成的亮色天空、平静海面与左侧小船',eyebrow:'SHORE / 02'},title:'沿岸\u0020*慢行*',body:'小船停在左下方。天空留给标题，水面的细节仍然清晰可见。'},
 'portrait':{meta:{image:`${dir}/assets/synthetic-quiet-portrait.png`,textZone:'top-left',alt:'AI 合成的虚构成年女性，人物位于右侧',caption:'虚构人物，AI 合成，非真实肖像。',eyebrow:'PORTRAIT / 03'},title:'[片刻](https://example.com)\u0020安静',body:'这是虚构成年人物的合成练习，不是采访、人物报道或身份记录。'},
 'three-line':{title:'在暗处留一束光给花枝',body:'文字与花枝分处两侧。',meta:{eyebrow:undefined}},
 'blocked-portrait':{meta:{image:'examples/templates/assets/synthetic-ceramic-artist.png',subjectSafety:'blocked',alt:'AI 合成的居中陶艺人物，近景无足够安全文字区',caption:'虚构人物，AI 合成。',eyebrow:undefined},title:'保留人物',body:'人物靠近画面边缘，本例要求完整保留。'},
 'uncertain':{meta:{subjectSafety:'uncertain',eyebrow:undefined},title:'先确认主体',body:'未完成主体与裁切检查，不能声明安全。'},
 'no-safe-zone':{meta:{image:'examples/templates/assets/synthetic-reading-still-life.png',textZone:'none',subjectSafety:'blocked',alt:'AI 合成的桌面静物，物件分布在文字区域内',eyebrow:undefined},title:'保留物件',body:'物件没有适合叠字的安静区，请使用完整图像。'},
 'no-crop-permission':{meta:{mediaFit:undefined,eyebrow:undefined},title:'完整呈现',body:'没有明确裁切授权，保持完整图像。'},
 'invalid-focus':{meta:{focalX:-1,focalY:101,eyebrow:undefined},title:'焦点越界',body:'非法坐标必须拒绝，不能自动夹紧。'},
 'title-overflow':{meta:{eyebrow:undefined},title:'在暗处留一束光给花枝然后继续记录那些安静而细小的瞬间',body:'长标题不缩小，不改写。'},
 'invalid-remote':{meta:{image:'https://example.com/photo.png'},title:'禁止远程',body:'只读取已授权的本地图片。'},
 'invalid-role':{meta:{imageRole:'screenshot',eyebrow:undefined},title:'证据不裁切',body:'截图证据不能借用照片封面的裁切能力。'}
};
for(const[id,item]of Object.entries(cases))await writeFile(`${dir}/${id}.md`,`<!-- card: ${JSON.stringify({...common,...item.meta})} -->\n# ${item.title}\n\n${item.body}\n`);
const original=await readFile('examples/templates/T37.md','utf8');
await writeFile(`${dir}/original.md`,original.replace('assets/synthetic-reading-still-life.png','examples/templates/assets/synthetic-reading-still-life.png'));
const assets=[];
for(const name of ['synthetic-dark-vase','synthetic-bright-shore','synthetic-quiet-portrait']){const bytes=await readFile(`${dir}/assets/${name}.png`);assets.push({file:`${name}.png`,sha256:createHash('sha256').update(bytes).digest('hex'),dimensions:[1536,1024],origin:'OpenAI built-in imagegen, newly generated 2026-10-26; no reference images',identity:'AI-generated fictional scene; no real person/place/product claimed',rights:'Original synthetic fixture; no third-party photo license inferred; no exclusive AI copyright claim'});}
await writeFile(`${dir}/assets/provenance.json`,JSON.stringify({schemaVersion:1,assets},null,2)+'\n');
