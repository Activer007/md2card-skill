import assert from 'node:assert/strict';
import{readFile,writeFile,mkdir}from'node:fs/promises';
import{createHash}from'node:crypto';
import{execFile}from'node:child_process';
import{promisify}from'node:util';
import{exportCards,parseOptions}from'../../scripts/render.mjs';
import{exportCards as oldExport}from'./baseline/scripts/render.mjs';
import{openRenderer,closeBrowser}from'../../scripts/browser.mjs';
const exec=promisify(execFile),hash=b=>createHash('sha256').update(b).digest('hex');
const root='validation/m2b/original-unbranded';await mkdir(root);
const options=parseOptions(['examples/templates/T37.md','--asset-root','examples/templates','--out',`${root}/current`,'--format','all','--preview','--strict','--browser','C:/Program Files/Google/Chrome/Application/chrome.exe']);
await exportCards(options);await oldExport({...options,out:`${root}/baseline`});
for(const mode of ['current','baseline'])await exec('pdftoppm',['-singlefile','-scale-to','1080','-png',`${root}/${mode}/cards.pdf`,`${root}/${mode}/native-pdf`],{windowsHide:true});
const comparisons=[];for(const file of ['cards.html','preview.html','card-001.png','native-pdf.png']){const before=hash(await readFile(`${root}/baseline/${file}`)),after=hash(await readFile(`${root}/current/${file}`));assert.equal(before,after,file);comparisons.push({file,sha256:after});}
const renderer=await openRenderer(options);
try{const html=await readFile(`${root}/current/preview.html`,'utf8');for(const width of [375,390]){await renderer.page.setViewportSize({width,height:900});await renderer.page.setContent(html);await renderer.page.evaluate(()=>document.fonts.ready);await renderer.page.screenshot({path:`${root}/current/mobile-${width}.png`});}}finally{await closeBrowser(renderer.browser);}
await writeFile(`${root}/comparison.json`,JSON.stringify({scope:'Unmodified original T37 example, legacy footer, no brand, default medium',baseCommit:'38bd0dbd44c8b85e3875fa70280f6d63167ed1c0',comparisons},null,2)+'\n');console.log('Original unbranded default HTML/preview/PNG/PDF page are exact.');
