from pathlib import Path
import hashlib,json,tarfile,io
root=Path('validation/m2b/run1');repo=Path.cwd();report=json.loads((root/'report.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in report['files']:
 p=root/f['file'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],f['file']
entries={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}
extra=Path('validation/m2b/original-unbranded')
entries.update({f'original-unbranded/{p.relative_to(extra).as_posix()}':p for p in extra.rglob('*') if p.is_file()})
for name in ['unit.log','proof-final-tests.log','variant-tests.log','integration.log','gallery-check.log','original-default.log']:
 entries[f'logs/{name}']=Path('validation/m2b')/name
for name in ['audit.py','package.py','stage-proof.mjs','proof.mjs','fixtures.mjs','original-default.mjs']:
 entries[f'review-tools/{name}']=Path('validation/m2b')/name
sources=set(x['file'] for x in report['sourceHashes'])
sources.update(['scripts/default-body-compatibility.mjs','scripts/validate-screenshot-stage.mjs','scripts/template-recommender.mjs','tests/photo-cover.test.mjs','tests/default-body-compatibility.test.mjs','references/rendering.md','docs/visual-upgrade/M2B_ACCEPTANCE.md','docs/visual-upgrade/M2B_PHOTO_COVER.md','docs/visual-upgrade/m2b-default-compatibility.json'])
sources.update(p.as_posix() for p in Path('examples/visual-upgrade/t37').rglob('*') if p.is_file())
entries.update({f'source-snapshot/{name}':Path(name) for name in sources})
files=[{'file':name,'bytes':p.stat().st_size,'sha256':sha(p)}for name,p in sorted(entries.items())]
manifest={'schemaVersion':1,'files':files,'automatedReportSha256':sha(root/'report.json'),'visualReviewSha256':sha(root/'visual-review.json'),'sourceSnapshotScope':'All reported interpretation dependencies, changed feature/review sources and photo fixtures; not node_modules/fonts/tools binaries.'}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
target=Path('docs/evidence/t37-photo-cover-m2b.tar.xz');assert not target.exists(),'Frozen evidence exists'
with tarfile.open(target,'w:xz',preset=9)as archive:
 for name,p in sorted(entries.items()):archive.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('archive-manifest.json');info.size=len(manifest_bytes);archive.addfile(info,io.BytesIO(manifest_bytes))
# Read back every archived byte and verify against the independently assembled inventory.
with tarfile.open(target,'r:xz')as archive:
 for f in files:
  member=archive.getmember(f['file']);assert member.isfile() and member.size==f['bytes'];assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==f['sha256'],f['file']
evidence={'schemaVersion':1,'date':'2026-10-26','scope':'T37 photo-cover independent review, default compatibility and explicit refusals','baseCommit':report['baselineIdentity']['commit'],'archive':{'file':target.as_posix(),'bytes':target.stat().st_size,'sha256':sha(target),'entryPoint':'index.html','fileCount':len(files)+1},'automatedReportSha256':sha(root/'report.json'),'visualReviewSha256':sha(root/'visual-review.json'),'outcomes':{'exported':12,'refused':8,'photoCovers':4,'explicitFallbacks':3},'visualInspection':{'individualViews':54,'description':'48 matrix PNG/mobile/PDF views, 2 differing screen/print image views, 4 additional unbranded original views. Agent review, not maintainer sign-off.'},'tests':{'unitInitial':{'total':608,'passed':606,'failed':2,'reason':'Proof hash updated during run; no source runtime failure.'},'affectedGroupAfterProofFreeze':{'total':50,'passed':50},'variantsFinal':{'total':12,'passed':12},'browserIntegration':{'total':21,'passed':21,'skipped':0},'gallery':'48 accepted defaults unchanged'},'defaultCompatibility':{'historicalHtmlCases':96,'existingStageHtmlCases':8,'originalT37':['HTML','preview HTML','PNG','native PDF page'],'unbrandedComparison':json.loads((extra/'comparison.json').read_text(encoding='utf-8'))},'limits':report['limitations']+['Pure-black brand accent exposes unchanged default contrast issues; these defaults are compatibility comparisons, not newly visually accepted designs.'],'sourceHashes':report['sourceHashes']}
Path('docs/visual-upgrade/m2b-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(evidence['archive']))
