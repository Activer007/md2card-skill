import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
const files=['scripts/document.mjs','scripts/markdown.mjs','scripts/render.mjs','scripts/body-size.mjs','scripts/templates.mjs','scripts/browser.mjs'];
// Git stores LF; normalize edited source before pinning executable bytes.
for(const file of files)await writeFile(file,(await readFile(file,'utf8')).replaceAll('\r\n','\n'));
const proof={schemaVersion:1,baseCommit:'38bd0dbd44c8b85e3875fa70280f6d63167ed1c0',scope:'without-photo-cover-only',verification:'Original 96 independently pinned default HTML cases, original T37 HTML/PNG/native PDF, and existing T20 stage fixture HTML. New photo-cover is independent evidence.',files:{}};
for(const file of files)proof.files[file]={baselineSha256:hash(await readFile(`validation/m2b/baseline/${file}`)),currentSha256:hash(await readFile(file))};
const bytes=JSON.stringify(proof,null,2)+'\n';await writeFile('docs/visual-upgrade/m2b-default-compatibility.json',bytes);
const verifier='scripts/default-body-compatibility.mjs';await writeFile(verifier,(await readFile(verifier,'utf8')).replace(/(PHOTO_DEFAULT_PROOF_SHA256 = ')[^']+/,`$1${hash(bytes)}`));
console.log('Proof',hash(bytes));
const p=JSON.parse(await readFile('package.json','utf8'));if(!p.scripts['test:unit'].includes('tests/photo-cover.test.mjs'))p.scripts['test:unit']+=' tests/photo-cover.test.mjs';p.scripts['validate:photo-cover']='node scripts/validate-photo-cover.mjs';await writeFile('package.json',JSON.stringify(p,null,2)+'\n');
