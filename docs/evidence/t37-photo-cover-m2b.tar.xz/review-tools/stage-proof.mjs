import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import{createHash}from'node:crypto';
import{renderCards}from'../../scripts/markdown.mjs';
import{buildDocument,SIZES}from'../../scripts/document.mjs';
import{createAssetResolver}from'../../scripts/assets.mjs';
import{renderCards as oldParse}from'./baseline/scripts/markdown.mjs';
import{buildDocument as oldBuild}from'./baseline/scripts/document.mjs';
const hash=b=>createHash('sha256').update(b).digest('hex');
const css=await Promise.all(['themes','layouts','templates'].map(n=>readFile(`assets/${n}.css`,'utf8')));
const oldCss=await Promise.all(['themes','layouts','templates'].map(n=>readFile(`validation/m2b/baseline/assets/${n}.css`,'utf8')));
const resolver=(await createAssetResolver('.')).resolveImage;
const records=[];
for(const id of ['dense-ui','desktop-16x9','desktop-4x3','long-body','long-source','long-title','original','tall-phone']){
 const input=`examples/visual-upgrade/t20/${id}.md`,source=await readFile(input,'utf8');
 const options={...SIZES.portrait,footerMode:'poster'};
 const old=oldBuild(oldParse(source,{resolveImage:resolver}),options,...oldCss),current=buildDocument(renderCards(source,{resolveImage:resolver}),options,...css);
 assert.equal(current,old,id);records.push({input,inputSha256:hash(source),baselineHtmlSha256:hash(old),options});
}
const file='docs/visual-upgrade/m2b-default-compatibility.json',proof=JSON.parse(await readFile(file,'utf8'));proof.stageRecords=records;
const bytes=JSON.stringify(proof,null,2)+'\n';await writeFile(file,bytes);
const v='scripts/default-body-compatibility.mjs';await writeFile(v,(await readFile(v,'utf8')).replace(/(PHOTO_DEFAULT_PROOF_SHA256 = ')[^']+/,`$1${hash(bytes)}`));
console.log('8 prior T20 stage HTML fixtures unchanged; proof',hash(bytes));
