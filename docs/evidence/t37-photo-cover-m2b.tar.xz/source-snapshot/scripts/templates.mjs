import { typographyForFamily } from './typography.mjs';
import { Md2CardError } from './errors.mjs';

// A registry entry describes a composed design, not a theme/size permutation.
// All CSS classes and paths come from this repository-owned allowlist.
const entries = [
  { id: 'T01', acceptance: 'visual-m1', name: '专题封面与侧栏导读', family: 'editorial', layout: 'cover', composition: 'cover-sidebar', purpose: '专题开篇、概念导读', image: 'none', length: [80, 180], structure: '一个 H1；开篇段落；一至两个 H2 侧栏。', unsuitable: '长文、宽表格和完整教程；可改用普通 explainer 分页。', focus: 'title', example: 'examples/templates/T01.md' },
  { id: 'T05', acceptance: 'visual-m1', maxListNumber: 99, name: '大数字索引清单', family: 'swiss', layout: 'steps', composition: 'numbered-index', purpose: '方法清单、阅读导航', image: 'none', length: [70, 160], structure: '一个 H1；三至四个完整有序列表项。保留原始起始编号；本模板编号范围为 0–99，超出请用普通 steps。', unsuitable: '长嵌套列表或大段说明；可用普通 steps 自动分页。', focus: 'body', example: 'examples/templates/T05.md' },
  { id: 'T17', acceptance: 'visual-m1', name: '荧光重点机制解析', family: 'technology', layout: 'explainer', composition: 'mechanism-rail', purpose: '机制、原理与系统解释', image: 'none', length: [90, 200], structure: '一个 H1；简短导语；三段 H2 机制说明。', unsuitable: '长代码或宽表格；可改用技术教程模板或普通 explainer。', focus: 'body', example: 'examples/templates/T17.md' },
  { id: 'T25', acceptance: 'visual-m1', name: '便签式阅读摘记', family: 'journal', layout: 'explainer', composition: 'reading-note', purpose: '阅读笔记、摘句与思考', image: 'none', length: [70, 170], structure: '一个 H1；引用块；一个 H2 下的阅读思考。', unsuitable: '密集数据、长篇引用；保留完整引文并增加手动卡片。', focus: 'body', example: 'examples/templates/T25.md' },
  {"id":"T02","acceptance":"visual-upgrade","name":"引语特写与证据出处","family":"editorial","layout":"quote","composition":"quotation-evidence","purpose":"观点摘引、证据提示与出处说明","image":"none","length":[90,170],"structure":"一个 H1；一个 25–45 字的引用块；两个 H2 证据短栏；来源写入 source，避免重复署名。","unsuitable":"长篇引文、三栏以上证据或宽表格；可拆成多张手动卡片，保留完整引文与出处。","focus":"quote","example":"examples/templates/T02.md"},
  {"id":"T06","acceptance":"visual-upgrade","name":"非对称双栏对比","family":"swiss","layout":"comparison","composition":"asymmetric-comparison","purpose":"两种方案、路径或判断方式的比较","image":"none","length":[80,140],"structure":"一个 H1；一段简短比较前提；两个接近等宽的 H2 对比栏，右栏保留较强视觉权重；后续 H2 为全宽补充。","unsuitable":"三个以上并列方案、长嵌套列表和宽表格；改用普通 comparison 多卡对比。","focus":"body","example":"examples/templates/T06.md"},
  {"id":"T09","acceptance":"visual-upgrade","name":"几何主题封面","family":"bauhaus","layout":"cover","composition":"geometric-cover","purpose":"概念专题开篇、工作坊主题与方法导读","image":"none","length":[80,150],"structure":"一个 6–10 字 H1；一段导语；两个 H2 短节。圆弧为标题留出独立区域，几何标记区分两段。","unsuitable":"长标题、详细教程与密集数据；改用解释卡，不缩小正文来填入封面。","focus":"title","example":"examples/templates/T09.md"},
  {"id":"T10","acceptance":"visual-upgrade","name":"模块拼贴概念卡","family":"bauhaus","layout":"explainer","composition":"modular-concept-collage","purpose":"概念拆解、设计原则与三段式知识介绍","image":"none","length":[80,140],"structure":"一个 H1；一段概念导语；两个 H2。导语与第一节并列，第二节为全宽综合模块。","unsuitable":"宽表格、长代码和层层嵌套的论证；可改用普通 explainer 分页。","focus":"body","example":"examples/templates/T10.md"},
  {"id":"T13","acceptance":"visual-upgrade","name":"超大字宣言","family":"brutalist","layout":"cover","composition":"declaration-poster","purpose":"行动主张、团队原则与明确的核心观点","image":"none","length":[80,150],"structure":"一个 6–10 字 H1 或连续 H1 标题组；一段导语；两个短 H2 论点条，标题以 2–4 字为宜。","unsuitable":"长标题、细节密集的政策与完整教程；拆卡并保留条件，不将宣言当作完整论证。","focus":"title","example":"examples/templates/T13.md"},
  {"id":"T14","acceptance":"visual-upgrade","name":"票据式行动清单","family":"brutalist","layout":"steps","composition":"action-ticket","purpose":"执行前检查、个人行动清单与打印任务票","image":"none","length":[80,150],"structure":"一个 H1；一句短导语；三至四项完整有序列表。编号保留输入起点，空框仅供打印后手动勾选。 本模板支持原始编号 0–99；超出请使用普通 steps。","unsuitable":"长嵌套任务、需要交互状态的待办应用；可用普通 steps 分页，不自动标记完成。","focus":"body","example":"examples/templates/T14.md","maxListNumber":99},
  {"id":"T18","acceptance":"visual-upgrade","name":"终端式技术教程","family":"technology","layout":"explainer","composition":"terminal-tutorial","purpose":"短代码演示、命令操作与结果核对","image":"none","length":[60,140],"structure":"一个 H1；简短导语；两个 H2 分别放真实代码和结果说明。建议一段不超过六行的短代码。","unsuitable":"长函数、超长命令或宽表格；请拆成手动卡片或使用普通 explainer 自动分页，不缩小代码。","focus":"body","example":"examples/templates/T18.md"},
  {"id":"T21","acceptance":"visual-upgrade","name":"单指标聚焦","family":"business","layout":"statistic","composition":"single-metric-focus","purpose":"突出一个指标，同时交代定义、范围与限制","image":"none","length":[70,150],"structure":"必须提供非空 metric 和 label；一个 H1；metric 和 label 提供指标与完整名称；导语后用两个 H2 分别说明口径与限制。","unsuitable":"多个竞争指标、超长数值、缺少分母或依据的数据；可改用 T22 或普通 explainer。","focus":"metric","supportedMetadata":["metric","label"],"example":"examples/templates/T21.md","requiredMetadata":["metric","label"]},
  {"id":"T22","acceptance":"visual-upgrade","name":"三指标证据板","family":"business","layout":"statistic","composition":"three-metric-evidence-board","purpose":"用三组指标与证据说明同一问题","image":"none","length":[80,160],"structure":"一个 H1；简短导语；恰好三个 H2，每个 H2 写短指标值，其后一个段落以加粗指标名开头，再说明分母或限定条件。","unsuitable":"需要横轴刻度的图表、超过三个指标或长篇方法学；请使用数据图或普通 explainer，不伪造指标凑版。","focus":"body","example":"examples/templates/T22.md"},
  {"id":"T26","acceptance":"visual-upgrade","name":"批注式学习清单","family":"journal","layout":"steps","composition":"annotated-study-checklist","purpose":"学习任务、复习清单与对应批注","image":"none","length":[80,150],"structure":"一个 H1；一句导语；两个 H2，每节包含两项简短无序清单及一个批注引用块。空方框是项目符号，不代表已完成。","unsuitable":"长嵌套任务、需要交互勾选或批注大于正文的内容；可改用普通 steps 或 explainer 分页。","focus":"body","example":"examples/templates/T26.md"},
  {"id":"T29","acceptance":"visual-upgrade","name":"题签留白书摘","family":"eastern","layout":"quote","composition":"title-label-quotation","purpose":"短书摘、原创语句与独立阅读理解","image":"none","length":[70,150],"structure":"一个短 H1；保留原始断句的引用块；一个 H2 下放个人理解；source 记录真实出处或原创身份。","unsuitable":"长篇节选、无法核对的名人语录和多级列表；不改句意、不虚构署名、不强制竖排。","focus":"quote","example":"examples/templates/T29.md"},
  {"id":"T30","acceptance":"visual-upgrade","name":"横排诗文与小景","family":"eastern","layout":"quote","composition":"horizontal-poem-small-scenery","purpose":"短诗、散文片段与安静的创作札记","image":"none","length":[60,130],"structure":"一个 H1；引用块放四至六行横排诗文，并用 Markdown 硬换行保留行分隔；一个 H2 放札记；小景为模板自带原创 CSS 几何构图。","unsuitable":"长诗、要求原作插图或真实摄影的图文；请另选图文模板，不把几何小景当作照片。","focus":"quote","example":"examples/templates/T30.md"},
  {"id":"T33","acceptance":"visual-upgrade","name":"报头式主题导读","family":"newspaper","layout":"cover","composition":"newspaper-masthead","purpose":"专题导读、读书周刊","image":"none","length":[80,170],"structure":"一个 H1 报头；一段导语；两个 H2 栏目。","unsuitable":"密集长文与多列表格；用普通解释卡分页。","focus":"title","example":"examples/templates/T33.md"},
  {"id":"T34","acceptance":"visual-upgrade","name":"专栏式观点分析","family":"newspaper","layout":"explainer","composition":"column-analysis","purpose":"观点分析与方法讨论","image":"none","length":[90,170],"structure":"一个 H1；短导语；两个 H2，分别为全宽主栏与缩进侧记。","unsuitable":"长引文与复杂嵌套；保留原文手动分卡。","focus":"body","example":"examples/templates/T34.md"},
  {"id":"T37","acceptance":"visual-upgrade","name":"大图与底部信息带","family":"film","layout":"image-caption","composition":"film-hero-band","purpose":"影像记录、照片与短故事","image":"required","length":[35,95],"structure":"元数据 image 为主要照片；一个 H1；简短故事；caption 和 source 说明图像性质与来源。","unsuitable":"以大量文字为主的内容；用图文分栏或普通解释卡。","focus":"image","example":"examples/templates/T37.md","provenance":{"assets":"Original synthetic illustrations; fictional/AI identity disclosed in examples. See examples/templates/assets/provenance.json and README.md."}},
  {"id":"T38","acceptance":"visual-upgrade","name":"接触印样式记录","family":"film","layout":"image-caption","composition":"contact-print-record","purpose":"多图观察、过程记录","image":"inline","length":[45,110],"structure":"一个 H1；两个 H2 图像记录，每节一个 Markdown 本地图片与一句说明。保持 DOM 读序。","unsuitable":"多于两幅的大型图集、长文；手动增加卡片，不隐藏图片。","focus":"image","example":"examples/templates/T38.md","inlineImageCount":{"min":2,"max":2},"imageSections":{"count":2,"perSection":1},"provenance":{"assets":"Original synthetic illustrations; fictional/AI identity disclosed in examples. See examples/templates/assets/provenance.json and README.md."}},
  {"id":"T41","acceptance":"visual-upgrade","name":"色块问答","family":"pop","layout":"explainer","composition":"color-block-question-answer","purpose":"问题解释、概念问答","image":"none","length":[70,160],"structure":"H1 提出问题；导语说明背景；两个 H2 分别展开答案与边界。","unsuitable":"长表格、代码和多层论证；改用对应专用模板。","focus":"body","example":"examples/templates/T41.md"},
  {"id":"T42","acceptance":"visual-upgrade","name":"贴纸式步骤卡","family":"pop","layout":"steps","composition":"sticker-steps","purpose":"轻量教程、三步行动","image":"none","length":[70,150],"structure":"一个 H1；三个有序列表项；保留真实列表编号。 本模板支持原始编号 0–99，超出使用普通 steps。","unsuitable":"密集嵌套步骤或代码；用技术教程或普通 steps 分页。","focus":"body","example":"examples/templates/T42.md","maxListNumber":99},
  {"id":"T45","acceptance":"visual-upgrade","name":"植物留白笔记","family":"nature","layout":"explainer","composition":"botanical-margin-note","purpose":"自然观察、生活笔记","image":"required","length":[65,150],"structure":"元数据 image 为保全的植物插画；一个 H1；导语与一个 H2 观察记录。","unsuitable":"密集数据、植物鉴定或医疗建议；这是笔记版式，不是科学鉴定工具。","focus":"body","example":"examples/templates/T45.md","provenance":{"assets":"Original synthetic illustrations; fictional/AI identity disclosed in examples. See examples/templates/assets/provenance.json and README.md."}},
  {"id":"T46","acceptance":"visual-upgrade","name":"暖色材料质感指南","family":"nature","layout":"image-caption","composition":"material-guide","purpose":"材质观察、生活物件使用笔记","image":"required","length":[70,150],"structure":"元数据 image 为材质场景；一个 H1；两个 H2 分别说明触感与养护边界。","unsuitable":"性能测评或未经证实的功效比较；保留产品真实资料。","focus":"body","example":"examples/templates/T46.md","provenance":{"assets":"Original synthetic illustrations; fictional/AI identity disclosed in examples. See examples/templates/assets/provenance.json and README.md."}},
  {"id":"T03","acceptance":"visual-upgrade","name":"图文分栏人物与概念介绍","family":"editorial","layout":"image-caption","composition":"portrait-editorial-spread","purpose":"一张竖图配人物练习、工艺介绍或单一概念","image":"required","length":[90,150],"structure":"一个 H1；一段短导语；两个短 H2；必须提供本地图片与说明。主文左侧、图片右侧，默认 contain 保全图片。","unsuitable":"长访谈、多人群像、宽截图和长图注；不要靠裁切或缩字塞入侧栏。示例人物和场景为 AI 生成虚构内容。","focus":"body","example":"examples/templates/T03.md","requiredMetadata":["alt","caption"],"provenance":{"assets":"Original AI-generated fictional adult portrait, full frame retained; see examples/templates/assets/provenance.json and README.md."}},
  {"id":"T04","acceptance":"visual-upgrade","name":"专题长文分节","family":"editorial","layout":"explainer","composition":"sectioned-editorial-essay","purpose":"同一论点的连续说明、专题正文页与系列卡片","image":"none","length":[140,220],"structure":"一个 H1；一句导语；三个 H2 短节，以连续全宽段落展开。较长全文须保留原文并手动拆卡。","unsuitable":"超长单段、宽表格和并排论点；这是正文优先设计，不代表单张容纳任意长文。","focus":"body","example":"examples/templates/T04.md"},
  {"id":"T07","acceptance":"visual-upgrade","name":"网格知识地图","family":"swiss","layout":"explainer","composition":"root-branches-synthesis-grid","purpose":"概念总览、根问题与两条分支的知识地图","image":"none","length":[110,180],"structure":"一个 H1；一句问题前提；四个 H2，依次为全宽根概念、两个并列分支、全宽综合。阅读顺序沿原文。","unsuitable":"四个完全等价的分类、三层以上树状结构、宽表格；等价四分类可改用 T12。","focus":"body","example":"examples/templates/T07.md"},
  {"id":"T08","acceptance":"visual-upgrade","maxListNumber":99,"name":"极简步骤导航","family":"swiss","layout":"steps","composition":"paired-step-navigation","purpose":"准备、执行与回看的短步骤路线","image":"none","length":[100,170],"structure":"一个 H1；一句导语；四个完整有序列表项，按先左后右、再到下一行阅读。原始编号保留，范围为 0–99。","unsuitable":"长嵌套清单、超过四个很长的步骤、超过两位的编号；可用普通 steps 分页。箭头与末项圆圈仅为导航装饰。","focus":"body","example":"examples/templates/T08.md"},
  {"id":"T11","acceptance":"visual-upgrade","name":"圆形节点流程","family":"bauhaus","layout":"steps","composition":"circular-heading-node-flow","purpose":"三阶段观察、试作、反馈或概念转化过程","image":"none","length":[100,180],"structure":"一个 H1；一句导语；三个 H2，每个标题建议 2 字，直接成为圆形节点文字；完整说明排列在节点右侧。","unsuitable":"长节点标题、分支决策树或大量阶段；长标题会使节点自然变高，不会缩字或截断。","focus":"body","example":"examples/templates/T11.md"},
  {"id":"T12","acceptance":"visual-upgrade","name":"几何分区四象限","family":"bauhaus","layout":"comparison","composition":"geometric-quadrant-field","purpose":"四种平行情况、原则分类或四方向观察","image":"none","length":[110,180],"structure":"一个 H1；一句分类前提；四个 H2 组成等宽四分区，按原文行序阅读。没有隐含坐标、得分或排名。","unsuitable":"数值散点、需要明确坐标轴的矩阵或五个以上等价分类；附加 H2 保留为全宽补充，不冒充第五象限。","focus":"body","example":"examples/templates/T12.md"},
  {"id":"T15","acceptance":"visual-upgrade","name":"粗线双阵营对照","family":"brutalist","layout":"comparison","composition":"two-camps-shared-wall","purpose":"两种取向的公平对照及共同适用边界","image":"none","length":[110,180],"structure":"一个 H1；一句比较前提；两个 H2 等宽阵营；第三个 H2 为全宽共同条件。不同底色不代表胜负。","unsuitable":"三个以上方案、长条款及把复杂争议强行二分；完整限制须保留在补充区或下一张卡。","focus":"body","example":"examples/templates/T15.md"},
  {"id":"T16","acceptance":"visual-upgrade","name":"黑白撞色观点合集","family":"brutalist","layout":"explainer","composition":"offset-monochrome-opinion-sheets","purpose":"同题短观点、创作原则与独立立场摘记","image":"none","length":[110,190],"structure":"一个 H1；一句总前提；三个 H2 原创短观点，每节标题上置、说明下置。交错纸片与点色区分观点。","unsuitable":"长篇人物引语、需要逐条出处的学术汇编；外部引语必须提供真实出处，不用样例冒充名言。","focus":"body","example":"examples/templates/T16.md"},
  {"id":"T19","acceptance":"visual-upgrade","name":"系统模块架构","family":"technology","layout":"explainer","composition":"shared-input-module-matrix","purpose":"解释系统的模块边界、输入与职责","image":"none","length":[80,160],"structure":"一个 H1；导语说明系统输入；四个 H2 分别命名模块并说明职责，形成两列两行的模块矩阵。模块顺序沿用原文。","unsuitable":"复杂拓扑、长 API 清单或需要真实箭头语义的架构图；请提供专门图示或拆为手动卡片，不用装饰冒充连接关系。","focus":"body","example":"examples/templates/T19.md"},
  {"id":"T20","acceptance":"visual-upgrade","name":"深色产品功能展示","family":"technology","layout":"image-caption","composition":"feature-pair-interface-stage","purpose":"展示产品主张、两个功能与一幅完整界面图","image":"required","length":[55,115],"structure":"一个 H1；一句导语；两个 H2 功能短说明；image 必须提供本地图片，alt 与 caption 说明图像性质。按标题、正文、图像、来源的 DOM 顺序展示。","unsuitable":"需要在手机上阅读密集界面小字、长功能列表或无图内容；图内细节不能代替图外正文，请改用专门界面细节卡或文本模板。","focus":"image","example":"examples/templates/T20.md","requiredMetadata":["alt","caption"],"provenance":{"assets":"Original programmatic fictional interface illustration, not a screenshot of an existing product; see examples/templates/assets/provenance.json and README.md."}},
  {"id":"T23","acceptance":"visual-upgrade","name":"问题—行动—结果案例","family":"business","layout":"case-study","composition":"problem-action-result-bridge","purpose":"说明案例背景、行动与有依据的结果边界","image":"none","length":[90,170],"structure":"一个 H1；导语交代案例性质；三个 H2 依次为问题、行动和结果。前两节并列，结果跨栏；假设或示例需明确标注。","unsuitable":"没有来源的企业业绩、虚构真实公司成效、需要多指标证据的方法学报告；保留证据与限制，必要时改用多卡案例。","focus":"body","example":"examples/templates/T23.md"},
  {"id":"T24","acceptance":"visual-upgrade","name":"报告式对比表","family":"business","layout":"comparison","composition":"report-table-decision-note","purpose":"用真实三列表格对照方式、适用情形与限制","image":"none","length":[90,170],"structure":"一个 H1；短导语；第一 H2 下为三列表格，第一列只放 1–2 位代码或短数字，后两列为解释；第二 H2 写选择依据。推荐三行表体，全文保持正文字号。","unsuitable":"长名称首列、超过三列的宽表、长表体或大段单元格；请用其他表格卡或手动分卡，不缩小单元格和代码。","focus":"body","example":"examples/templates/T24.md"},
  {"id":"T27","acceptance":"visual-upgrade","name":"时间线学习计划","family":"journal","layout":"steps","composition":"dated-study-timeline","purpose":"按阶段整理学习目标、练习与检验方式","image":"none","length":[80,150],"structure":"一个 H1；导语写总目标；三个 H2 使用作者提供的短时间标签，如第 1 周；各自一个段落写任务与检验。时间不由模板生成。","unsuitable":"精确排程、交互进度、多层子任务或过长日期；请转用日历或普通 steps，不把计划显示成已完成。","focus":"body","example":"examples/templates/T27.md"},
  {"id":"T28","acceptance":"visual-upgrade","maxListNumber":99,"name":"索引卡知识整理","family":"journal","layout":"steps","composition":"numbered-index-slips","purpose":"用稳定索引整理概念、定义与回看线索","image":"none","length":[80,150],"structure":"一个 H1；短导语；一个 H2 下放三个有序列表项，每项以加粗概念开头，再写解释。编号来自原始列表；固定索引签仅支持 0–99。","unsuitable":"超过 99 的编号、长嵌套列表或多段长定义；改用普通 steps 或分卡，保留原始编号，不重置为 1。","focus":"body","example":"examples/templates/T28.md"},
  {"id":"T31","acceptance":"visual-upgrade","name":"印章式个人语录","family":"eastern","layout":"quote","composition":"personal-quotation-geometric-seal","purpose":"呈现个人短句、真实人物原话与独立思考","image":"none","length":[55,120],"structure":"一个短 H1；引用块保留原始断句；一个 H2 下写个人理解。source 只记真实出处或原创身份；朱印仅为空白几何装饰，不生成作者姓名。","unsuitable":"无法核实的人物语录、长篇书摘或要求真实印鉴的内容；不虚构作者、印文或归属，必要时使用普通 quote。","focus":"quote","example":"examples/templates/T31.md"},
  {"id":"T32","acceptance":"visual-upgrade","name":"书页章节解读","family":"eastern","layout":"explainer","composition":"chapter-excerpt-reading-bands","purpose":"区分章节摘句与读者解读，保留作品来源","image":"none","length":[90,170],"structure":"一个 H1；导语交代章节语境；两个 H2 分别放短引用块与个人理解，形成前后成对的全宽阅读带。引用与解读不能互相冒充。","unsuitable":"整章复制、长篇节选、窄栏长代码与不明出处文本；使用获授权的短摘句，或明确原创演示并手动分卡。","focus":"body","example":"examples/templates/T32.md"},
  {"id":"T35","acceptance":"visual-upgrade","name":"剪报拼贴资料卡","family":"newspaper","layout":"explainer","composition":"dated-source-clipping-stack","purpose":"并列保存资料片段、记录日期和各自出处","image":"none","length":[100,190],"structure":"一个 H1；短导语；两个 H2 资料片段，每节依次写明确日期/出处、引用块与必要边界。片段来源不得被省略或拼成新结论。","unsuitable":"未注明来源的摘句、需要暗示因果的拼贴或长篇全文；原文过长请手动分卡。","focus":"body","example":"examples/templates/T35.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original explicitly fictional source fragments and dates; not actual event reporting.","assets":"No picture assets; local system fonts only."}},
  {"id":"T36","acceptance":"visual-upgrade","name":"大标题事件回顾","family":"newspaper","layout":"explainer","composition":"headline-event-record","purpose":"用大标题、真实日期和连续事实记录回顾事件","image":"none","length":[100,180],"structure":"一个 H1 事件标题；导语说明范围；三个 H2 包含作者提供的日期与事件名称；各节保留事实及资料链接。模板不生成日期或事实。","unsuitable":"没有来源的事件结论、跨时区却不注明口径的精确时间、宣传口号；不把未验证消息当事实。","focus":"title","example":"examples/templates/T36.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original Chinese paraphrase of NASA Apollo 11 mission and lunar-event records; verified URLs in docs/template-source-references.json.","assets":"No picture assets; local system fonts only."}},
  {"id":"T39","acceptance":"visual-upgrade","name":"人像与侧栏故事","family":"film","layout":"image-caption","composition":"portrait-field-story-sidebar","purpose":"让完整人像成为主区，标题、故事与署名占据同一侧栏","image":"required","length":[55,110],"structure":"必需本地人像 image、真实 alt 和说明性质的 caption；一个短 H1；短导语与一至两个 H2。标题与正文共用较宽的右侧叙述栏，完整人像在左侧贯穿两区。","unsuitable":"无图人物报道、长传记、必须裁切才能成立的肖像；侧栏不是小字容器，保留主体或换图。","focus":"image","example":"examples/templates/T39.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original explicitly fictional character story; not a real interview or biography.","assets":"Original AI-generated fictional adult portrait, reused without alteration; exact original hash recorded in the integrated provenance. See examples/templates/assets/provenance.json and README.md."},"requiredMetadata":["alt","caption"],"figureBeforeMain":true},
  {"id":"T40","acceptance":"visual-upgrade","maxListNumber":99,"name":"局部特写与知识注释","family":"film","layout":"image-caption","composition":"explicit-detail-numbered-key","purpose":"把明确选取的独立特写图与逐号注释对应","image":"required","length":[80,150],"structure":"image 必须是明确提供的特写图，caption 交代它是独立细节源或经用户授权的预裁切图；一个 H1；简短导语与两至三个有序注释。原生编号保留，固定编号签范围 0–99。","unsuitable":"未经授权裁切整图、把局部冒充全貌、图中编号与正文不匹配；当前模板不提供自动裁切。","focus":"image","example":"examples/templates/T40.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original explanation limited to visible lines in the explicit detail illustration; no product-performance claim.","assets":"Original code-native PNG illustrations; reproducible drawing source and SHA-256 provenance supplied. No third-party art or external fonts bundled. See examples/templates/assets/provenance.json and README.md."},"requiredMetadata":["alt","caption"],"figureBeforeMain":true},
  {"id":"T43","acceptance":"visual-upgrade","name":"漫画分镜知识解释","family":"pop","layout":"image-caption","composition":"comic-two-scenes-wide-resolution","purpose":"用原创分镜呈现明确的情境、做法与结论边界","image":"inline","length":[70,140],"structure":"一个 H1；导语标明情境性质；三个 H2 按作者给定编号排序，每节一个本地 Markdown 原创/许可图片与一个短对话或说明；第三格横贯两栏。","unsuitable":"无许可漫画、连续长对白、图片数量与说明不一致，或为情节捏造事实；拆卡而非缩字。","focus":"image","example":"examples/templates/T43.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original fictional comic dialogue and explanation; not experimental evidence.","assets":"Original code-native PNG illustrations; reproducible drawing source and SHA-256 provenance supplied. No third-party art or external fonts bundled. See examples/templates/assets/provenance.json and README.md."},"inlineImageCount":{"min":3,"max":3},"imageSections":{"perSection":1,"standalone":true,"descriptionRequired":true,"count":3}},
  {"id":"T44","acceptance":"visual-upgrade","name":"趣味双选项对比","family":"pop","layout":"comparison","composition":"dimension-led-paired-dialogues","purpose":"以同一维度逐行比较两个选项，不预设胜负","image":"none","length":[100,180],"structure":"一个 H1；导语明确两个选项；前两个 H2 分别是比较维度，每节两个引用块，保留同顺序的显式选项标签；后续 H2 为全宽条件。","unsuitable":"缺失一组选项、混用比较维度、评分推荐或过长气泡；不从缺失字段推断优劣。","focus":"body","example":"examples/templates/T44.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original same-dimension comparison of two optional activities; no automatic recommendation or health claim.","assets":"No picture assets; local system fonts only."},"pairedQuoteSections":2},
  {"id":"T47","acceptance":"visual-upgrade","name":"料理步骤图文","family":"nature","layout":"steps","composition":"ingredient-band-illustrated-method","purpose":"材料清单、明确用量与逐步示意图配对","image":"inline","length":[90,160],"structure":"一个 H1；导语明确食谱是否实测；材料用无序列表写真实用量或注明未提供；两个 H2 写作者提供的步骤编号，每节一个 Markdown 步骤图与一段操作。","unsuitable":"漏量却要求精确配方、缺少步骤图、需要安全温度却未给出，或图文不一致；不得为美观补造数量。","focus":"body","example":"examples/templates/T47.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original untested demonstration recipe with explicit quantities and non-scale illustrations; not measured results.","assets":"Original code-native PNG illustrations; reproducible drawing source and SHA-256 provenance supplied. No third-party art or external fonts bundled. See examples/templates/assets/provenance.json and README.md."},"inlineImageCount":{"min":2,"max":2},"imageSections":{"perSection":1,"standalone":true,"descriptionRequired":true,"count":2}},
  {"id":"T48","acceptance":"visual-upgrade","name":"生活方式产品比较","family":"nature","layout":"comparison","composition":"paired-full-image-specimen-columns","purpose":"让产品图、同一组对比字段与适用限制逐件对应","image":"inline","length":[100,180],"structure":"一个 H1；导语交代资料性质；前两个 H2 为产品，组成等权双列；每节在完整本地 Markdown 图片后列出相同顺序的两项字段；后续 H2 写全宽共同限制。","unsuitable":"未经验证的价格、功效、评分、材质或实时推荐；示例对象虚构无品牌，不推断真实产品规格。","focus":"body","example":"examples/templates/T48.md","provenance":{"design":"Original md2card-skill composition, MIT","text":"Original comparison of fictional unbranded object structures; no real price, rating, material or efficacy claim.","assets":"Original code-native PNG illustrations; reproducible drawing source and SHA-256 provenance supplied. No third-party art or external fonts bundled. See examples/templates/assets/provenance.json and README.md."},"inlineImageCount":{"min":2,"max":2},"imageSections":{"perSection":1,"standalone":true,"descriptionRequired":true,"minimumCount":2,"imageSectionCount":2}}
];

function freeze(value) {
  if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
  return value;
}
// Canvas dimensions, never metadata strings, select these repository-owned classes.
// Keep the pre-M9 ratio tolerance; custom sizes must match one supported ratio.
export const TEMPLATE_ASPECT_TOLERANCE = 0.002;
export const TEMPLATE_ASPECTS = freeze([
  { id: 'portrait', ratio: 3 / 4, numerator: 3, denominator: 4, className: 'template-aspect-portrait' },
  { id: 'square', ratio: 1, numerator: 1, denominator: 1, className: 'template-aspect-square' },
  { id: 'slide', ratio: 16 / 9, numerator: 16, denominator: 9, className: 'template-aspect-slide' }
]);
const independentAspects = {
  T04: {
    square: { composition: 'essay-thesis-rail', structure: 'Full-width title; thesis at left, sequential section stack at right; full-width source.', example: 'examples/aspects/T04-square.md' },
    slide: { composition: 'essay-title-rail-section-rows', structure: 'Left title rail; right introduction and labeled section rows; full-width source band.', example: 'examples/aspects/T04-slide.md' }
  },
  T05: {
    square: { composition: 'numbered-index-four-tile', structure: 'Compact title bar; two-by-two numbered reading tiles in source order; full-width source.', example: 'examples/aspects/T05-square.md', pendingReview: true }
  },
  T13: {
    square: { composition: 'declaration-rail-argument-stack', structure: 'Left slogan rail; right premise and vertically read argument panels; full-width source.', example: 'examples/aspects/T13-square.md', pendingReview: true }
  },
  T24: {
    slide: { composition: 'decision-rail-table-stage', structure: 'Left title, premise and decision rail; right complete comparison table; full-width source.', example: 'examples/aspects/T24-slide.md', pendingReview: true }
  },
  T37: {
    slide: { composition: 'film-frame-story-rail', structure: 'Left full-frame image and caption; right title and short story; full-width source.', example: 'examples/aspects/T37-slide.md', pendingReview: true }
  },
  T21: {
    square: { composition: 'metric-paired-headline', structure: 'Title and metric form paired top panels; introduction and evidence below; full-width source.', example: 'examples/aspects/T21-square.md' },
    slide: { composition: 'metric-source-rail-evidence', structure: 'Title, metric and source form a left rail; full-height evidence column at right.', example: 'examples/aspects/T21-slide.md' }
  }
};
// A changed design must earn new evidence. Old batches remain immutable history.
export const REFINED_TEMPLATE_IDS = Object.freeze(entries.map(entry => entry.id));
export const M1_REFINED_TEMPLATE_IDS = Object.freeze(['T06','T10','T16','T19','T20','T22','T24','T26','T32','T34','T39','T40','T45']);
function currentEntry(entry) {
  if (!REFINED_TEMPLATE_IDS.includes(entry.id)) return entry;
  const { acceptance, ...rest } = entry;
  const followsM1 = M1_REFINED_TEMPLATE_IDS.includes(entry.id);
  return { ...rest, version: followsM1 ? 3 : 2, acceptance: followsM1 ? 'refinement-m2-v3' : 'refinement-m2-v2', historicalAcceptance: { batch: acceptance, version: 1 },
    ...(followsM1 ? { historicalAcceptances: [{ batch: 'refinement-m1-v2', version: 2 }] } : {}),
    refinement: 'family-art-direction-v2' };
}
function aspectLayouts(entry) {
  return Object.fromEntries([
    ['portrait', { composition: entry.composition, example: entry.example, version: entry.version ?? 1,
      status: entry.acceptance ? 'visually-reviewed' : 'implemented-awaiting-visual-review',
      ...(entry.acceptance ? { acceptance: entry.acceptance } : {}) }],
    ...Object.entries(independentAspects[entry.id] ?? {}).map(([aspect, { pendingReview, ...layout }]) => [aspect, {
      ...layout, version: pendingReview ? 1 : 2, status: 'implemented-awaiting-visual-review',
      ...(pendingReview ? {} : { historicalAcceptance: { batch: 'visual-upgrade-aspects', version: 1 }, historicalEvidence: 'docs/aspect-upgrade-provenance.json' }),
      boundaries: pendingReview
        ? 'First implementation of this aspect using current M2 family typography. Registered short example requires new full PNG, 375/390px and native PDF inspection. No fit or visual acceptance is claimed.'
        : 'Historical v1 evidence reviewed only the registered standard-density short example at its declared canvas size. Current v2 exact short-fixture PNG/mobile/native-PDF artifacts are independently reviewed in REFINEMENT_M2_ACCEPTANCE.md; final aspect-specific binding remains pending R12. No universal fit guarantee.'
    }])
  ]);
}
export const TEMPLATES = freeze(entries.map(currentEntry).map(entry => ({
  ...entry, version: entry.version ?? 1, status: entry.acceptance ? 'visually-reviewed' : 'implemented-awaiting-visual-review', aspects: ['portrait', ...Object.keys(independentAspects[entry.id] ?? {})], aspectLayouts: aspectLayouts(entry), reading: 'mobile', density: 'standard',
  typography: typographyForFamily(entry.family),
  spacing: { insetWidthRatio: 0.052, densityAffects: 'spacing-only' },
  provenance: { design: 'Original md2card-skill composition, MIT', text: 'Original demonstration text; not an attributed external quotation', assets: 'No external assets; local system fonts only', ...entry.provenance }
})));
const byId = new Map(TEMPLATES.map(entry => [entry.id, entry]));
export const DENSITIES = Object.freeze(['compact', 'standard', 'editorial']);
export function getTemplate(id) {
  const template = byId.get(id);
  if (!template) throw new Md2CardError('INVALID_TEMPLATE', `Unknown template "${id}". Choose ${TEMPLATES.map(item => item.id).join(', ')}.`, { template: id });
  return template;
}
/** Resolve from actual canvas geometry, never from CSS, filenames or user classes. */
export function resolveTemplateAspect(id, { width, height } = {}) {
  const template = getTemplate(id);
  if (![width, height].every(value => Number.isInteger(value) && value >= 200 && value <= 4096)) {
    throw new Md2CardError('TEMPLATE_ASPECT_UNSUPPORTED', 'Template canvas dimensions must be integers from 200 to 4096 pixels.', { template: id, width, height });
  }
  // Exact integer comparison implements the same inclusive .002 window without
  // rejecting boundary values such as 1002/1000 due to floating subtraction.
  const aspect = TEMPLATE_ASPECTS.find(item => Math.abs(width * item.denominator - height * item.numerator) * (1 / TEMPLATE_ASPECT_TOLERANCE) <= height * item.denominator);
  if (!aspect || !template.aspects.includes(aspect.id)) {
    throw new Md2CardError('TEMPLATE_ASPECT_UNSUPPORTED', `${id} supports ${template.aspects.join(', ')} only. Choose a supported --size; an unimplemented aspect never stretches the portrait layout.`, { template: id, width, height, supported: template.aspects });
  }
  return aspect;
}
export function validateTemplateMetadata(metadata, { width, height } = {}) {
  const photo = metadata.template === 'T37' && metadata.visualVariant === 'photo-cover';
  if (metadata.visualVariant !== undefined && !photo && (metadata.template !== 'T20' || metadata.visualVariant !== 'screenshot-stage')) {
    throw new Md2CardError('INVALID_METADATA', 'visualVariant supports only T20 "screenshot-stage" or T37 "photo-cover".');
  }
  const photoFields = ['imageRole', 'mediaFit', 'focalX', 'focalY', 'textZone', 'mediaTone', 'subjectSafety'];
  if (!photo && photoFields.some(key => metadata[key] !== undefined)) throw new Md2CardError('INVALID_METADATA', 'Photo crop fields require explicit T37 photo-cover; other templates and image roles cannot crop.');
  if (photo) {
    const fail = detail => { throw new Md2CardError('INVALID_METADATA', `T37 photo-cover: ${detail} To preserve the complete image, remove visualVariant and all photo crop fields and use default T37.`); };
    if (metadata.imageRole !== 'photo') fail('imageRole must be "photo", never a screenshot or evidence diagram.');
    if (metadata.mediaFit !== 'cover') fail('mediaFit="cover" is required as explicit crop permission.');
    for (const key of ['focalX', 'focalY']) if (typeof metadata[key] !== 'number' || !Number.isFinite(metadata[key]) || metadata[key] < 0 || metadata[key] > 100) fail(`${key} must be a finite JSON number from 0 to 100.`);
    if (!['top-left', 'top-right', 'bottom-left', 'bottom-right'].includes(metadata.textZone)) fail('textZone must select one of the four corner regions; no safe zone means no overlay.');
    if (!['dark', 'light'].includes(metadata.mediaTone)) fail('mediaTone must describe the selected region as "dark" or "light".');
    if (metadata.subjectSafety !== 'clear') fail('subjectSafety="clear" requires the author to check both crop and text zone; blocked or uncertain subjects must not be overlaid.');
    for (const key of ['alt', 'caption', 'source']) if (typeof metadata[key] !== 'string' || !metadata[key].trim()) fail(`nonempty ${key} is required to preserve identity and provenance.`);
    if ((width !== undefined || height !== undefined) && resolveTemplateAspect('T37', { width, height }).id !== 'portrait') throw new Md2CardError('TEMPLATE_ASPECT_UNSUPPORTED', 'T37 photo-cover supports portrait only. Use default T37 for other supported aspects.');
  }
  if (metadata.aspect !== undefined) throw new Md2CardError('TEMPLATE_ASPECT_METADATA_UNSUPPORTED', 'Card aspect metadata is not supported. Use --size or matching canvas dimensions; CSS classes are derived internally.');
  if (metadata.template === undefined) {
    if (metadata.density !== undefined) throw new Md2CardError('INVALID_TEMPLATE', 'Card density requires an explicit template. Legacy theme behavior is unchanged.');
    return null;
  }
  const template = getTemplate(metadata.template);
  if (metadata.layout !== undefined && metadata.layout !== template.layout) throw new Md2CardError('TEMPLATE_LAYOUT_MISMATCH', `${template.id} requires layout "${template.layout}"; remove the conflicting layout or choose another template.`, { template: template.id });
  if (metadata.density !== undefined && !DENSITIES.includes(metadata.density)) throw new Md2CardError('INVALID_TEMPLATE', `Density must be ${DENSITIES.join(', ')}. It changes spacing, never font size.`);
  const unsupported = [...['metric', 'label'].filter(key => !template.supportedMetadata?.includes(key)), ...(['required', 'optional'].includes(template.image) ? [] : ['alt', 'caption'])].filter(key => metadata[key] !== undefined);
  if (unsupported.length) throw new Md2CardError('TEMPLATE_METADATA_UNSUPPORTED', `${template.id} does not display ${unsupported.join(', ')}. Choose a matching layout; metadata is never silently discarded.`, { fields: unsupported });
  const missing = (template.requiredMetadata ?? []).filter(key => typeof metadata[key] !== 'string' || !metadata[key].trim());
  if (missing.length) throw new Md2CardError('TEMPLATE_METADATA_REQUIRED', `${template.id} requires nonempty ${missing.join(', ')}. Supply the actual value and its label; no data is invented.`, { fields: missing });
  if (metadata.image !== undefined && !['required', 'optional'].includes(template.image)) throw new Md2CardError('TEMPLATE_IMAGE_UNSUPPORTED', `${template.id} does not accept a metadata image. Use its declared image mode or choose another template; images are never discarded.`);
  if (template.image === 'required' && (typeof metadata.image !== 'string' || !metadata.image.trim())) throw new Md2CardError('TEMPLATE_IMAGE_REQUIRED', `${template.id} requires a local metadata image; provide image, alt and optional caption. Nothing is fetched automatically.`, { template: template.id });
  if (width !== undefined || height !== undefined) resolveTemplateAspect(template.id, { width, height });
  return template;
}


export function validateTemplateCard(card, template) {
  if (!template) return;
  const inlineImages = (card.html.match(/<img\b/g) ?? []).length;
  if (card.metadata?.visualVariant === 'photo-cover') {
    if (inlineImages) throw new Md2CardError('TEMPLATE_IMAGE_COUNT', 'T37 photo-cover accepts one metadata photo and no inline images. Split extra images into separate cards.');
    if ((card.templateTitleHtml?.match(/<h1\b/g) ?? []).length !== 1 || (card.html.match(/<h1\b/g) ?? []).length !== 1) throw new Md2CardError('TEMPLATE_TITLE_REQUIRED', 'T37 photo-cover requires exactly one H1 title as extractable text.');
  }
  if (card.metadata?.visualVariant === 'screenshot-stage' && inlineImages) throw new Md2CardError('TEMPLATE_IMAGE_COUNT', 'T20 screenshot-stage accepts one metadata image and no inline images. Split additional screenshots into separate cards.');
  if (template.image === 'none' && (inlineImages || card.image)) throw new Md2CardError('TEMPLATE_IMAGE_UNSUPPORTED', `${template.id} is text-only; images are never discarded.`);
  if (template.image === 'inline' && card.image) throw new Md2CardError('TEMPLATE_IMAGE_UNSUPPORTED', `${template.id} uses inline images, not a separate metadata image.`);
  if (template.image === 'required' && !card.image) throw new Md2CardError('TEMPLATE_IMAGE_REQUIRED', `${template.id} requires a resolver-validated local image.`);
  if (template.inlineImageCount && (inlineImages < template.inlineImageCount.min || inlineImages > template.inlineImageCount.max)) throw new Md2CardError('TEMPLATE_IMAGE_COUNT', `${template.id} needs ${template.inlineImageCount.min}–${template.inlineImageCount.max} inline images. Supply complete image/description pairs or split the card.`, { template: template.id, actual: inlineImages });

  if (template.imageSections) {
    const sections = card.sections ?? [], rule = template.imageSections;
    const imageSectionCount = rule.imageSectionCount ?? rule.count;
    const selected = sections.slice(0, imageSectionCount);
    const wrongCount = (rule.count !== undefined && sections.length !== rule.count) || (rule.minimumCount !== undefined && sections.length < rule.minimumCount);
    const badImage = selected.length !== imageSectionCount || selected.some(section => (section.html.match(/<img\b/g) ?? []).length !== rule.perSection || (rule.standalone && section.shape?.standaloneImageParagraphs !== rule.perSection) || (rule.descriptionRequired && !section.shape?.descriptionBlocks));
    if (wrongCount || badImage || /<img\b/.test(card.templateIntroHtml ?? '') || sections.slice(imageSectionCount).some(section => /<img\b/.test(section.html))) throw new Md2CardError('TEMPLATE_IMAGE_STRUCTURE', `${template.id} requires ${imageSectionCount} H2 image records, each with ${rule.perSection} image and its explanation. Keep images in their declared records; no text or image is discarded.${rule.standalone ? ' Images must be standalone unlinked Markdown paragraphs, not mixed with text.' : ''}`, { template: template.id });
  }
  if (template.pairedQuoteSections) {
    const sections = (card.sections ?? []).slice(0, template.pairedQuoteSections);
    if (sections.length !== template.pairedQuoteSections || sections.some(section => section.shape?.topLevelBlockquotes !== 2 || section.shape?.nonemptyTopLevelBlockquotes !== 2)) throw new Md2CardError('TEMPLATE_OPTION_STRUCTURE', `${template.id} requires two nonempty sibling quotation blocks in each of its first ${template.pairedQuoteSections} comparison dimensions. Nested or empty quotes are not separate supplied options.`, { template: template.id });
  }
  if (template?.maxListNumber !== undefined) {
    for (const list of card.orderedLists ?? []) {
      if (list.start < 0 || list.start + list.count - 1 > template.maxListNumber) {
        throw new Md2CardError('TEMPLATE_LIST_RANGE', `${template.id} supports list numbers 0–${template.maxListNumber}. Use the legacy steps layout for wider counters; numbers are never changed.`, { template: template.id, start: list.start, count: list.count });
      }
    }
  }
}
