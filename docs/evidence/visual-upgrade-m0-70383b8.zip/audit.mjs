import { spawn } from 'node:child_process';
const child=spawn('C:/Users/10747/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',['validation/visual-upgrade/m0-70383b8-20261025/audit.py'],{stdio:'inherit',windowsHide:true});
child.on('error',e=>{console.error(e);process.exitCode=1;});
child.on('exit',code=>process.exitCode=code??1);
