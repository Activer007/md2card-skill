import sys, json, hashlib, struct, subprocess, shutil, re, platform
from pathlib import Path
from collections import Counter
from importlib.metadata import version
from pypdf import PdfReader
from PIL import Image, ImageOps, ImageDraw

root=Path(__file__).resolve().parent
def save(name,data): (root/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def digest(file): return hashlib.sha256(Path(file).read_bytes()).hexdigest()
def command(args):
    p=subprocess.run(args,capture_output=True,text=True,encoding='utf8',errors='replace',timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
    return {'command':list(map(str,args)),'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
tools={}
for name in ['pdfinfo','pdftoppm','pdftotext','fc-list','fc-match']:
    exe=shutil.which(name)
    tools[name]={'path':exe,'version':command([exe,'-v']) if exe else None,'status':'available' if exe else 'BLOCKED: executable missing'}
save('python-environment.json',{'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'packages':{m:version(m) for m in ['pypdf','pdfplumber','pypdfium2','Pillow']},'tools':tools,'fontTools':'not installed; font name/version tables read directly from SFNT files'})

# Direct OpenType name-table inventory (read only, including TTC face offsets).
font_results=[]
for name in ['NotoSansSC-VF.ttf','NotoSerifSC-VF.ttf','CascadiaMono.ttf','msyh.ttc','msyhbd.ttc','arial.ttf','arialbd.ttf','GOTHIC.TTF']:
    file=Path('C:/Windows/Fonts')/name
    data=file.read_bytes()
    u16=lambda o:struct.unpack_from('>H',data,o)[0]
    u32=lambda o:struct.unpack_from('>I',data,o)[0]
    offsets=[u32(12+4*i) for i in range(u32(8))] if data[:4]==b'ttcf' else [0]
    faces=[]
    for offset in offsets:
        tables={data[p:p+4].decode('latin1'):u32(p+8) for p in range(offset+12,offset+12+16*u16(offset+4),16)}
        base=tables['name'];strings=base+u16(base+4);names={}
        for p in range(base+6,base+6+12*u16(base+2),12):
            plat,enc,lang,nid,length,start=struct.unpack_from('>6H',data,p)
            if nid not in [1,2,4,5,6,16,17]: continue
            raw=data[strings+start:strings+start+length]
            try:value=raw.decode('utf-16-be' if plat in [0,3] else 'mac_roman')
            except UnicodeDecodeError:continue
            names.setdefault(str(nid),set()).add(value)
        faces.append({k:sorted(v) for k,v in names.items()})
    font_results.append({'file':str(file),'sha256':digest(file),'bytes':len(data),'faces':faces})
save('font-files.json',font_results)

goldens=json.loads((root/'goldens.json').read_text(encoding='utf8'))
pdf_results=[]
compact=lambda s:re.sub(r'\s+','',s)
for case in goldens:
    out=root/'outputs'/case['id'];file=out/'cards.pdf'
    reader=PdfReader(file);text='\n'.join(page.extract_text() or '' for page in reader.pages)
    (out/'pdf-text.txt').write_text(text,encoding='utf8')
    required=Counter(compact(s) for s in case['segments'])
    missing=[{'segment':s,'requiredCount':n,'actualCount':compact(text).count(s)} for s,n in required.items() if compact(text).count(s)<n]
    pages=[]
    for page in reader.pages:
        fonts=[]
        for key,fontref in page['/Resources'].get('/Font',{}).items():
            font=fontref.get_object();descendants=font.get('/DescendantFonts',[])
            descendants=[f.get_object() for f in descendants] or [font]
            descriptors=[f.get('/FontDescriptor',{}).get_object() if hasattr(f.get('/FontDescriptor',{}),'get_object') else f.get('/FontDescriptor',{}) for f in descendants]
            fonts.append({'resource':str(key),'name':str(font.get('/BaseFont')),'subtype':str(font.get('/Subtype')),'toUnicode':'/ToUnicode' in font,'embedded':any(any(k in d for k in ['/FontFile','/FontFile2','/FontFile3']) for d in descriptors)})
        pages.append({'widthPt':float(page.mediabox.width),'heightPt':float(page.mediabox.height),'fonts':fonts})
    info=command([tools['pdfinfo']['path'],str(file)])
    raster=command([tools['pdftoppm']['path'],'-f','1','-singlefile','-scale-to','1440','-png',str(file),str(out/'pdf-page-1')])
    pass_text=len(reader.pages)==1 and not missing and bool(text.strip())
    result={'id':case['id'],'pdfSha256':digest(file),'extractor':'pypdf '+version('pypdf'),'pageCount':len(reader.pages),'pages':pages,'textCharacters':len(text),'requiredSegments':len(case['segments']),'missing':missing,'textStatus':'pass' if pass_text else 'fail','pdfinfo':info,'raster':raster,'rasterSha256':digest(out/'pdf-page-1.png') if raster['exitCode']==0 else None,'officialPdftotextGate':'BLOCKED: pdftotext missing; independent pypdf evidence does not replace this gate'}
    if case['id']=='T05':
        result['listNumbers']={str(n):bool(re.search(r'(?<!\d)'+str(n)+r'(?!\d)',text)) for n in range(1,5)}
    pdf_results.append(result)
save('pdf-audit.json',pdf_results)

# Review contact sheets preserve complete images; original pixels remain beside them.
for case in goldens:
    out=root/'outputs'/case['id']
    panel=Image.new('RGB',(1500,850),'#dddddd');d=ImageDraw.Draw(panel)
    files=['card-001.png','mobile-375.png','mobile-390.png','pdf-page-1.png']
    for i,name in enumerate(files):
        im=Image.open(out/name).convert('RGB');im.thumbnail((360,810))
        panel.paste(im,(i*375+(375-im.width)//2,35));d.text((i*375+8,10),case['id']+' '+name,fill='black')
    panel.save(out/'review-contact.png')
print(json.dumps({'pdfText':[{'id':r['id'],'status':r['textStatus'],'segments':r['requiredSegments']} for r in pdf_results],'fonts':len(font_results)},ensure_ascii=False))
if any(r['textStatus']!='pass' or r['raster']['exitCode']!=0 for r in pdf_results):sys.exit(1)
