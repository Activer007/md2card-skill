import { readFile,writeFile,mkdir,copyFile,readdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import os from 'node:os';
import { parseOptions,exportCards } from '../../../scripts/render.mjs';
import { openRenderer,closeBrowser } from '../../../scripts/browser.mjs';
import { TEMPLATES,TEMPLATE_ASPECTS } from '../../../scripts/templates.mjs';
import { LAYOUTS,renderCards } from '../../../scripts/markdown.mjs';
import { createAssetResolver } from '../../../scripts/assets.mjs';
import { authoredSegments } from '../../../scripts/validate-visual-stress.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const hash=b=>createHash('sha256').update(b).digest('hex');
const json=async(f,v)=>writeFile(path.join(root,f),JSON.stringify(v,null,2)+'\n');
const bounded=async(p,label)=>{let timer;try{return await Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`${label} timed out`)),30000);})]);}finally{clearTimeout(timer);}};
const ids=['T20','T37','T01','T05'];
await mkdir(path.join(root,'inputs','assets'),{recursive:true});
await mkdir(path.join(root,'outputs'),{recursive:true});
const tracked=execFileSync('git',['ls-files','scripts','assets','package.json','package-lock.json','SKILL.md'],{encoding:'utf8'}).trim().split(/\r?\n/);
const sourceHashes=[];
for(const file of tracked)sourceHashes.push({file,sha256:hash(await readFile(file))});
await json('source.json',{capturedAt:new Date().toISOString(),commit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),tree:execFileSync('git',['rev-parse','HEAD^{tree}'],{encoding:'utf8'}).trim(),node:process.version,os:{platform:os.platform(),release:os.release(),architecture:os.arch()},package:JSON.parse(await readFile('package.json','utf8')),sourceHashes,templates:TEMPLATES.map(({id,version,aspects,status})=>({id,version,aspects,status})),layouts:LAYOUTS,aspectDefinitions:TEMPLATE_ASPECTS});
const plans='C:/Users/10747/.workbuddy/skills/md2card-skill/md2card-guizang-development-pack';
await json('plan-hashes.json',await Promise.all((await readdir(plans)).filter(f=>f.endsWith('.md')).map(async file=>({file,sha256:hash(await readFile(path.join(plans,file)))}))));
const results=[];
for(const id of ids){
  console.log(`Export ${id}`);
  const input=`examples/templates/${id}.md`, bytes=await readFile(input), source=bytes.toString('utf8');
  await copyFile(input,path.join(root,'inputs',`${id}.md`));
  const resolver=await createAssetResolver('examples/templates');
  const cards=renderCards(source,{resolveImage:resolver.resolveImage});
  const assets=resolver.getAssets().map(({dataUrl,...asset})=>asset);
  for(const asset of assets)await copyFile(path.join('examples/templates',asset.reference),path.join(root,'inputs',asset.reference));
  const out=path.join(root,'outputs',id);
  const args=[input,'--asset-root','examples/templates','--out',out,'--preview','--timeout-ms','600000'];
  const startedAt=new Date().toISOString();
  const manifest=await exportCards(parseOptions(args));
  const result={id,input,inputSha256:hash(bytes),assets,command:['node','scripts/render.mjs',...args],startedAt,finishedAt:new Date().toISOString(),cardCount:manifest.cardCount,styleSha256:manifest.styleSha256,pdfQa:manifest.qa.pdf,segments:cards.flatMap(authoredSegments),mobile:[]};
  const renderer=await openRenderer({width:1080,height:1440,scale:1,timeoutMs:60000});
  try{
    result.chromium=renderer.browser.version();
    await renderer.page.setContent(await readFile(path.join(out,'preview.html'),'utf8'),{waitUntil:'load',timeout:30000});
    await bounded(renderer.page.evaluate(()=>document.fonts.ready),'fonts');
    const session=await renderer.context.newCDPSession(renderer.page);
    await session.send('DOM.enable');await session.send('CSS.enable');
    const doc=await session.send('DOM.getDocument');
    const nodes=await session.send('DOM.querySelectorAll',{nodeId:doc.root.nodeId,selector:'.card h1,.card h2,.card p,.card li,.card-source,.card-eyebrow,.card-footer,figcaption'});
    result.platformFonts=[];
    for(const nodeId of nodes.nodeIds){
      const {node}=await session.send('DOM.describeNode',{nodeId});
      const fonts=await session.send('CSS.getPlatformFontsForNode',{nodeId});
      result.platformFonts.push({nodeName:node.nodeName,attributes:node.attributes,fonts:fonts.fonts});
    }
    for(const width of [375,390]){
      await renderer.page.setViewportSize({width,height:800});
      const metrics=await bounded(renderer.page.evaluate(()=>{
        const card=document.querySelector('.card'),r=card.getBoundingClientRect(),scale=r.width/card.offsetWidth;
        const active=e=>e.textContent.trim()&&e.getBoundingClientRect().width>0;
        const body=[...card.querySelectorAll('.template-intro p,.template-intro li,.template-section p,.template-section li')].filter(active);
        const notes=[...card.querySelectorAll('.card-source,.card-eyebrow,.card-footer,figcaption')].filter(active);
        return {card:{x:r.x,y:r.y,width:r.width,height:r.height},scale,bodyMin:body.length?Math.min(...body.map(e=>parseFloat(getComputedStyle(e).fontSize)*scale)):null,noteMin:notes.length?Math.min(...notes.map(e=>parseFloat(getComputedStyle(e).fontSize)*scale)):null,documentWidth:document.documentElement.scrollWidth,images:[...card.querySelectorAll('img')].map(e=>({naturalWidth:e.naturalWidth,naturalHeight:e.naturalHeight,width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height,objectFit:getComputedStyle(e).objectFit,alt:e.alt,complete:e.complete}))};
      }),'mobile metrics');
      const file=`mobile-${width}.png`;
      await renderer.page.screenshot({path:path.join(out,file),fullPage:true,animations:'disabled',timeout:30000});
      result.mobile.push({viewportWidth:width,file,sha256:hash(await readFile(path.join(out,file))),...metrics});
    }
  }finally{await closeBrowser(renderer.browser);}
  results.push(result);await json('goldens.json',results);console.log(`Captured ${id}`);
}
