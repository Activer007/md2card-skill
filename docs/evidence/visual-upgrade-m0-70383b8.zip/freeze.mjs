import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,mkdir,copyFile,stat} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const hash=b=>createHash('sha256').update(b).digest('hex');
const read=async p=>JSON.parse(await readFile(path.join(root,p),'utf8'));
const json=async(p,v)=>writeFile(p,JSON.stringify(v,null,2)+'\n');
const source=await read('source.json'),goldens=await read('goldens.json'),rejections=await read('rejections.json');
const checked=[];
for(const file of source.sourceHashes){assert.equal(hash(await readFile(file.file)),file.sha256,file.file);checked.push(file.file);}
assert.equal(execFileSync('git',['diff','--name-only',source.commit,'--','scripts','assets','examples','package.json','package-lock.json','SKILL.md','docs/gallery'],{encoding:'utf8'}).trim(),'');
const fixtureFile='tests/fixtures/visual-upgrade/m0-cases.json',fixture=JSON.parse(await readFile(fixtureFile,'utf8'));
for(const caseItem of fixture.goldens){
  const golden=goldens.find(x=>x.id===caseItem.id);caseItem.inputSha256=golden.inputSha256;
  assert.equal(hash(await readFile(caseItem.input)),golden.inputSha256);
  assert.equal(hash(await readFile(path.join(root,'inputs',`${caseItem.id}.md`))),golden.inputSha256);
  const out=path.join(root,'outputs',caseItem.id),manifest=JSON.parse(await readFile(path.join(out,'manifest.json'),'utf8'));
  assert.equal(manifest.inputSha256,golden.inputSha256);assert.equal(manifest.bodySize,'medium');assert.equal(manifest.footerMode,'legacy');
  assert.equal(manifest.cardCount,1);
  for(const c of manifest.cards){assert.equal(c.screen.overflow.length,0);assert.equal(c.print.overflow.length,0);}
  for(const artifact of manifest.artifacts)assert.equal(hash(await readFile(path.join(out,artifact.file))),artifact.sha256);
  const png=await readFile(path.join(out,'card-001.png'));assert.equal(png.readUInt32BE(16),1080);assert.equal(png.readUInt32BE(20),1440);
  for(const mobile of golden.mobile){assert.ok(mobile.documentWidth<=mobile.viewportWidth);assert.ok(mobile.bodyMin>=14);assert.ok(mobile.noteMin>=11);assert.equal(hash(await readFile(path.join(out,mobile.file))),mobile.sha256);}
  for(const asset of golden.assets)assert.equal(hash(await readFile(path.join(root,'inputs',asset.reference))),asset.hash);
}
assert.equal(rejections.length,4);assert.ok(rejections.every(x=>x.status==='pass'&&x.exitCode===1&&x.files.length===0));
await json(fixtureFile,fixture);
const installed='C:/Users/10747/.workbuddy/skills/md2card-skill',drift=[];
for(const file of ['package.json','SKILL.md','scripts/body-size.mjs','scripts/render.mjs','scripts/document.mjs','scripts/markdown.mjs','scripts/templates.mjs','scripts/assets.mjs','assets/templates.css']){
 const repoHash=hash(await readFile(file));let installedHash=null;
 try{installedHash=hash(await readFile(path.join(installed,file)));}catch(e){if(e.code!=='ENOENT')throw e;}
 drift.push({file,repoSha256:repoHash,installedSha256:installedHash,status:installedHash===null?'missing':repoHash===installedHash?'same':'different'});
}
await json(path.join(root,'installation-drift.json'),{directory:installed,repoVersion:source.package.version,installedVersion:JSON.parse(await readFile(path.join(installed,'package.json'),'utf8')).version,files:drift});
const commandRecords=[];
for(const name of (await readdir(path.join(root,'commands'))).filter(f=>f.endsWith('.json')).sort())commandRecords.push(await read(`commands/${name}`));
await json(path.join(root,'commands.json'),commandRecords);
await json(path.join(root,'verification.json'),{checkedAt:new Date().toISOString(),command:['node','validation/visual-upgrade/m0-70383b8-20261025/freeze.mjs'],checks:{runtimeFilesUnchanged:checked.length,productionGitDiff:'empty',originalInputsAndCopiedBytes:'pass',manifestArtifacts:'pass',pngDimensions:'pass',screenPrintOverflow:'none',mobileBoundsAndMinimumFonts:'pass',copiedAssetIdentity:'pass',rejections:'4/4'},exitCode:0,limitations:['Official Fontconfig/Poppler strict gate BLOCKED','pypdf authored-segment comparison FAIL retained','T05 PDFium complete-list-segment order mismatch retained']});
const deliverables=['docs/visual-upgrade/BASELINE.md','docs/visual-upgrade/BASELINE-EVIDENCE.md','docs/visual-upgrade/REGRESSION.md','docs/visual-upgrade/ADR-001.md','tests/fixtures/visual-upgrade/m0-cases.json','tests/fixtures/visual-upgrade/invalid-metadata.md','tests/fixtures/visual-upgrade/remote-image.md'];
for(const file of deliverables){const to=path.join(root,'review-files',file);await mkdir(path.dirname(to),{recursive:true});await copyFile(file,to);}
const files=[];
async function walk(dir){for(const entry of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const full=path.join(dir,entry.name);if(entry.isDirectory())await walk(full);else if(entry.isFile()){const relative=path.relative(root,full).replaceAll('\\','/');if(relative==='evidence-index.json')continue;const bytes=await readFile(full);files.push({file:relative,bytes:bytes.length,sha256:hash(bytes)});}}}
await walk(root);
await json(path.join(root,'evidence-index.json'),{schemaVersion:1,baselineCommit:source.commit,baselineTree:source.tree,files});
const archive=path.join(path.dirname(root),'m0-70383b8-20261025-evidence.zip');
// Store only this task's evidence, not installed fonts or the external planning pack.
const py='import pathlib,sys,zipfile; r=pathlib.Path(sys.argv[1]); z=zipfile.ZipFile(sys.argv[2],"x",zipfile.ZIP_DEFLATED); [z.write(f,f.relative_to(r).as_posix()) for f in sorted(r.rglob("*")) if f.is_file()]; z.close()';
execFileSync('C:/Users/10747/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',['-c',py,root,archive],{windowsHide:true,timeout:60000});
const evidence={schemaVersion:1,status:'baseline-frozen-with-explicit-limitations',baseline:{commit:source.commit,tree:source.tree,packageVersion:source.package.version},evidenceDirectory:path.relative(process.cwd(),root).replaceAll('\\','/'),archive:{file:path.relative(process.cwd(),archive).replaceAll('\\','/'),bytes:(await stat(archive)).size,sha256:hash(await readFile(archive))},indexSha256:hash(await readFile(path.join(root,'evidence-index.json'))),environment:{node:source.node,os:source.os,chrome:goldens[0].chromium,dependencies:source.package.dependencies,python:await read('python-environment.json'),fonts:await read('font-files.json')},planHashes:await read('plan-hashes.json'),sourceHashes:source.sourceHashes,templates:source.templates,layouts:source.layouts,commands:commandRecords.map(c=>({name:c.name,exitCode:c.exitCode,startedAt:c.startedAt,finishedAt:c.finishedAt})),goldens:goldens.map(c=>({id:c.id,input:c.input,inputSha256:c.inputSha256,styleSha256:c.styleSha256,assets:c.assets,output:`outputs/${c.id}`})),verification:await read('verification.json'),evidenceFiles:files};
await json('docs/visual-upgrade/m0-provenance.json',evidence);
console.log(JSON.stringify({archive:evidence.archive,evidenceFiles:files.length,runtimeFiles:checked.length,productionDiff:'empty',fixtureCount:fixture.goldens.length+fixture.rejections.length}));
