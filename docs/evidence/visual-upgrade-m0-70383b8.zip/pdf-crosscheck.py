import json,re,unicodedata,sys
from pathlib import Path
from collections import Counter
import pypdfium2 as pdfium
import pdfplumber
from importlib.metadata import version
root=Path(__file__).resolve().parent
goldens=json.loads((root/'goldens.json').read_text(encoding='utf8'))
results=[]
def compact(text):return re.sub(r'\s+','',text)
def missing(text,segments,form):
    norm=lambda s:compact(unicodedata.normalize(form,s))
    counts=Counter(norm(s) for s in segments)
    return [{'segment':s,'required':n,'actual':norm(text).count(s)} for s,n in counts.items() if norm(text).count(s)<n]
for case in goldens:
    out=root/'outputs'/case['id']; pdf=pdfium.PdfDocument(out/'cards.pdf')
    text='\n'.join(page.get_textpage().get_text_range() for page in pdf)
    with pdfplumber.open(out/'cards.pdf') as doc:plumber='\n'.join(p.extract_text() or '' for p in doc.pages)
    entries=[]
    for name,content in [('pypdf', (out/'pdf-text.txt').read_text(encoding='utf8')),('pypdfium2',text),('pdfplumber',plumber)]:
        (out/f'{name}-text.txt').write_text(content,encoding='utf8')
        changes=[{'character':c,'codepoint':f'U+{ord(c):04X}','name':unicodedata.name(c,''),'compatibilityEquivalent':unicodedata.normalize('NFKC',c)} for c in sorted(set(content)) if unicodedata.normalize('NFKC',c)!=c]
        entries.append({'extractor':name,'version':version(name),'characters':len(content),'nfcMissing':missing(content,case['segments'],'NFC'),'nfkcMissingDiagnosticOnly':missing(content,case['segments'],'NFKC'),'compatibilityCharacters':changes})
    results.append({'id':case['id'],'extractors':entries,'note':'NFKC is diagnostic only; it does not change or relax the NFC fidelity gate.'})
(root/'pdf-crosscheck.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps([{'id':r['id'],'extractors':[{'name':e['extractor'],'nfcMissing':len(e['nfcMissing']),'nfkcMissing':len(e['nfkcMissingDiagnosticOnly'])} for e in r['extractors']]} for r in results]))
