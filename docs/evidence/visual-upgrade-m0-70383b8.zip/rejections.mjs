import { readFile,writeFile,readdir } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url)),run=promisify(execFile);
const cases=JSON.parse(await readFile('tests/fixtures/visual-upgrade/m0-cases.json','utf8'));
const results=[];
for(const item of cases.rejections){
 const out=path.join(root,'rejections',item.id),args=['scripts/render.mjs',item.input,...item.args,'--out',out,'--json'];
 let record;
 try{const result=await run(process.execPath,args,{timeout:30000,windowsHide:true});record={...result,exitCode:0};}
 catch(error){record={stdout:error.stdout,stderr:error.stderr,exitCode:error.code};}
 const files=await readdir(out).catch(error=>error.code==='ENOENT'?[]:Promise.reject(error));
 let error;try{error=JSON.parse(record.stderr||record.stdout);}catch{}
 const code=error?.error?.code??error?.code;
 const status=record.exitCode!==0&&code===item.expectedCode&&files.length===0?'pass':'fail';
 results.push({...item,command:[process.execPath,...args],...record,actualCode:code,files,status});
}
await writeFile(path.join(root,'rejections.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results));if(results.some(r=>r.status==='fail'))process.exitCode=1;
