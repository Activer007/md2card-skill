import { spawn } from 'node:child_process';
import { createWriteStream } from 'node:fs';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const [name, ...given] = process.argv.slice(2);
await mkdir(path.join(root, 'commands'), {recursive:true});
let args = given;
if (name === 'unit' || name === 'integration') {
  const pkg=JSON.parse(await readFile('package.json','utf8'));
  args=pkg.scripts[`test:${name}`].split(' ').slice(1);
}
const record={name, command:[process.execPath,...args],cwd:process.cwd(),startedAt:new Date().toISOString(),environment:{CHROMIUM_PATH:process.env.CHROMIUM_PATH,MD2CARD_REQUIRE_BROWSER:process.env.MD2CARD_REQUIRE_BROWSER,MD2CARD_REQUIRE_PDF_CHECK:process.env.MD2CARD_REQUIRE_PDF_CHECK??null}};
const log=createWriteStream(path.join(root,'commands',`${name}.log`));
const child=spawn(process.execPath,args,{stdio:['ignore','pipe','pipe'],windowsHide:true});
child.stdout.pipe(log,{end:false}); child.stderr.pipe(log,{end:false});
child.on('error',error=>record.error=error.message);
child.on('close',async(exitCode,signal)=>{
  record.finishedAt=new Date().toISOString(); record.exitCode=exitCode;record.signal=signal;
  await new Promise(resolve=>log.end(resolve));
  await writeFile(path.join(root,'commands',`${name}.json`),JSON.stringify(record,null,2)+'\n');
  console.log(JSON.stringify(record));process.exitCode=exitCode??1;
});
